# Portfolio Publishing Guide

How to get this project live, public, and linkable — for your CV, LinkedIn, and
job applications. Do all of these once; each takes 10-30 minutes.

---

## 1. GitHub (the anchor for everything else)

GitHub is the single most-checked link by recruiters/hiring managers for a data
analyst role. This is your priority.

1. Create a free account at https://github.com if you don't have one.
2. Create a new **public** repository, e.g. `fintech-analytics-portfolio`.
3. Unzip this project locally, then either:
   - Use the GitHub web UI: **Add file > Upload files**, drag in the whole
     folder structure, or
   - Use git from a terminal:
     ```bash
     cd fintech-analytics-portfolio
     git init
     git add .
     git commit -m "Initial commit: full fintech analytics project"
     git branch -M main
     git remote add origin https://github.com/<your-username>/fintech-analytics-portfolio.git
     git push -u origin main
     ```
4. Rename `README.md` (already included, at the project root) so it's the
   first thing visitors see — GitHub renders it automatically on the repo
   homepage, including the Mermaid ERD diagram in `docs/SCHEMA_DIAGRAM.md`.
5. **Do NOT commit `fintech.db` if you consider it sensitive** — this dataset is
   synthetic and safe to share, but as a habit: add a `.gitignore` for any real
   client data in future projects.
6. Add topics/tags to the repo (gear icon next to "About"): `data-analytics`,
   `sql`, `python`, `tableau`, `power-bi`, `fintech`, `portfolio-project`.
7. Pin the repository on your GitHub profile (Profile > Customize your pins).

## 2. GitHub Pages (free hosting for the written case study)

Turn `docs/BUSINESS_CASE.md` into a small live webpage:
1. In the repo, go to **Settings > Pages**.
2. Source: **Deploy from a branch** → branch `main`, folder `/docs`.
3. GitHub gives you a live URL like
   `https://<username>.github.io/fintech-analytics-portfolio/BUSINESS_CASE.html`
   within a minute or two (Markdown files render as pages automatically with
   the default Jekyll theme).

## 3. Tableau Public

1. Follow `tableau/TABLEAU_GUIDE.md` to build the workbook in Tableau Public
   Desktop (free download).
2. **File > Save to Tableau Public As...** — this uploads it directly and gives
   you a public URL: `https://public.tableau.com/app/profile/<you>/viz/<name>`.
3. Add a description on the Tableau Public page: 2-3 sentences on the dataset
   and your top finding.
4. Link back to your GitHub repo in the Tableau Public profile bio.

## 4. Power BI Service

1. Follow `powerbi/POWERBI_GUIDE.md` to build the report in Power BI Desktop.
2. **Home > Publish** to push it to the Power BI Service (app.powerbi.com),
   free account.
3. To make it publicly viewable without a Power BI login: open the report in
   the service → **File > Publish to web** → copy the embed link/iframe code.
   (Only do this because the dataset is synthetic and safe to expose publicly —
   never do this with real client or employer data.)
4. Put the link/embed on your portfolio site.

## 5. Kaggle (bonus — reaches a different audience: data scientists/analysts)

1. Create a free account at https://kaggle.com.
2. **Datasets > New Dataset** — upload the `data/raw/` CSVs (Kaggle doesn't take
   `.db` files well; CSVs are safest) with a short description.
3. **Code > New Notebook** — upload `python/Fintech_Analytics_Full_Project.ipynb`
   attached to that dataset, so it runs and displays your charts directly on
   Kaggle. This gives you a second, independently-discoverable public artifact.

## 6. LinkedIn

1. Go to your profile → **Featured** section → **Add > Link** (or **Add media**
   for the Excel file / a PDF export of the notebook).
2. Add the GitHub repo link, the Tableau Public link, and the Power BI link as
   three separate Featured items, OR write one LinkedIn post that links to all
   three, with 2-3 screenshots (export chart PNGs from `docs/charts/`).
3. Suggested post structure: *"I built a full-stack fintech analytics project
   covering SQL, Python, Excel, Tableau and Power BI on a 1,000-customer mobile
   money dataset. Key findings: [insight 1], [insight 2]. Links below 👇"*
4. Add the project to your LinkedIn profile's **Projects** section too (not just
   Featured) — it's a distinct, searchable field recruiters filter on.

## 7. Personal portfolio website (optional but strong signal)

If you don't have one yet, the fastest free options:
- **Notion** (public page, free): paste in the business case, embed the
  Tableau Public viz (Notion supports embeds via URL), and link the GitHub repo.
- **GitHub Pages with a template** (e.g. the "Just the Docs" or "Minimal
  Mistakes" Jekyll themes) if you want something more custom than plain
  Markdown rendering.
- **Carrd.co** (free tier) for a single polished landing page linking to all
  of the above.

## 8. Resume / CV bullet (copy-and-adapt)

> Built an end-to-end fintech analytics project (SQL, Python, Excel, Tableau,
> Power BI) analyzing 3,000+ mobile-money transactions and 500 loans; performed
> RFM customer segmentation, cohort retention analysis, fraud-exposure
> quantification, and Portfolio-at-Risk reporting; built a loan-default
> classification model. [github.com/you/fintech-analytics-portfolio]

---

## Suggested order of operations
1. GitHub repo (10 min) → 2. Run/verify the notebook & SQL locally (15 min) →
2. Tableau Public publish (30-45 min to rebuild the dashboard) →
3. Power BI publish (30-45 min) → 4. LinkedIn post + Featured links (10 min) →
5. (Optional) Kaggle + personal site.

Total: a focused afternoon gets this fully live across five platforms.
