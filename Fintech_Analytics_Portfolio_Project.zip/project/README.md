# Kenyan Fintech Analytics — Full-Stack Data Analyst Portfolio Project

An end-to-end analytics project on a realistic mobile-money / digital-lending
dataset (M-Pesa-style), built across **SQL, Python, Excel, Tableau, and Power
BI** — the full toolkit a fintech data analyst is expected to know.

> 📌 **New here? Read this file top to bottom once, then jump into whichever
> folder matches the tool you want to practice or showcase.**

---

## What's in this project

| Folder | What it is | Tool |
|---|---|---|
| `data/` | Raw exported tables + a clean star-schema data model | SQLite, CSV |
| `sql/` | Schema setup + 31 real business-question queries | SQL (SQLite dialect, portable to Postgres/MySQL with minor tweaks) |
| `python/` | Fully executed Jupyter notebook: EDA, RFM, cohort retention, fraud analysis, PAR, and a loan-default ML model | Python (pandas, seaborn, scikit-learn) |
| `excel/` | Formula-driven workbook: KPI dashboard, trend/channel/RFM/loan-risk sheets, native charts | Excel |
| `tableau/` | Build guide + calculated fields + CSV extracts | Tableau (Public or Desktop) |
| `powerbi/` | Build guide + DAX measures + CSV extracts | Power BI |
| `docs/` | Data dictionary, ERD/schema diagram, business case, and exported charts | Markdown |
| `portfolio/` | Step-by-step instructions to publish this project on GitHub, Tableau Public, Power BI Service, Kaggle, LinkedIn | — |

---

## The dataset, in one paragraph

`data/fintech.db` (SQLite) models a Kenyan mobile-money and digital-lending
platform: **1,000 customers**, **1,000 accounts**, **3,015 transactions**
(payments, transfers, bill payments, merchant payments, withdrawals across
Mobile/USSD/Agent/App channels), **500 loans** with **766 repayments**, **150
fraud alerts**, **150 merchants**, and **100 cash agents**, spread across **15
Kenyan counties** and roughly two years of activity (2024-2025). Every figure
is in Kenyan Shillings (KES). See `docs/DATA_DICTIONARY.md` for full column-level
documentation and `docs/SCHEMA_DIAGRAM.md` for the entity-relationship diagram.

---

## Quick start by tool

### SQL
```bash
# Any SQLite client works, e.g. DB Browser for SQLite, or the CLI:
sqlite3 data/fintech.db
.read sql/01_schema_setup.sql
.read sql/02_business_questions.sql
```

### Python
```bash
cd python
pip install pandas numpy matplotlib seaborn scikit-learn jupyter
jupyter notebook Fintech_Analytics_Full_Project.ipynb
```
The notebook is already executed with all outputs/charts saved — open it to
read the analysis immediately, or re-run it (`Kernel > Restart & Run All`) to
reproduce everything from scratch. It expects `data/fintech.db` at
`../data/fintech.db` relative to the notebook (already the case in this
folder structure).

### Excel
Open `excel/Fintech_Analyst_Workbook.xlsx` directly — start on the `README`
tab inside the workbook, then `KPI_Dashboard`. Every number is a live formula.

### Tableau / Power BI
Follow `tableau/TABLEAU_GUIDE.md` or `powerbi/POWERBI_GUIDE.md` — both use the
CSV extracts already sitting in those folders (copied from
`data/star_schema/`).

---

## What this project demonstrates (skills map)

**Data analyst / fintech core skills**
- Relational data modeling (star schema: facts + dimensions)
- SQL: joins, window functions (`NTILE`, `RANK`, `ROW_NUMBER`), CTEs, views,
  date functions, data-quality auditing
- Excel: `SUMIFS`/`COUNTIFS`/`AVERAGEIFS`, `IFS`, Excel Tables, conditional
  formatting, native charts, a self-documenting workbook
- BI dashboard design: Tableau calculated fields, Power BI DAX & data modeling,
  consistent cross-tool KPI definitions
- Python: EDA, data cleaning/QA, feature engineering, visualization

**Fintech-specific analytics concepts**
- Total Processing Value (TPV) & fee-revenue tracking
- Channel success/failure/reversal rate (payments ops health)
- RFM customer segmentation & cohort retention analysis
- Fraud rate, exposure (KES), and risk-driver analysis
- Credit risk: Portfolio-at-Risk (PAR), DPD buckets, default-rate drivers
- A supervised ML model for loan-default prediction (with an honest read on
  its limitations — see notebook §9)

---

## A note on rigor

Every SQL query in `sql/02_business_questions.sql` was executed against the
database and confirmed to run without error. The Python notebook was executed
end-to-end with zero errors and all 10 charts were generated from the actual
data. The Excel workbook's ~1,900 formulas were verified with zero calculation
errors via LibreOffice recalculation. Nothing in this project is a mockup — every
number you'll see came out of the real (synthetic) dataset.

---

## Next steps for you
1. Run through each tool once yourself so you can speak to the numbers
   confidently in an interview.
2. Read `docs/BUSINESS_CASE.md` and fill in your own 3-5 headline findings.
3. Follow `portfolio/PORTFOLIO_GUIDE.md` to publish this on GitHub, Tableau
   Public, Power BI Service, and LinkedIn.
