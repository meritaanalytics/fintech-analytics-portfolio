# Project Brief: Kenyan Fintech Analytics

## The scenario (frame it this way in interviews / your portfolio write-up)

You are the analyst on the data team of a Kenyan mobile-money and digital-lending
platform (an M-Pesa-style super-app). Leadership has three standing concerns:

1. **Growth & revenue** — is transaction volume and fee revenue growing month over
   month, and which channels/products drive it?
2. **Risk** — how exposed is the lending book to default, and how much fraud is
   slipping through, in which channels?
3. **Retention** — are customers sticking around after signup, and which segments
   are worth investing retention budget in?

You were asked to build a self-service analytics layer so Product, Risk, and Growth
teams stop asking the data team for one-off numbers — covering the full stack:
raw SQL for the data warehouse, Python for deeper modeling, and BI dashboards
(Excel, Tableau, Power BI) for the people who live in spreadsheets and slide decks.

## Objectives → deliverables map

| Business objective | Deliverable | Where |
|---|---|---|
| Track TPV, revenue, and channel health | KPI dashboard, monthly trend | SQL Section A, Excel `KPI_Dashboard`/`Monthly_Trend`, Tableau/Power BI "Executive Overview" |
| Understand and grow the customer base | RFM segmentation, cohort retention | SQL Section B, Python §5-6, Excel `Customer_RFM` |
| Manage credit risk on the loan book | Portfolio-at-Risk, default drivers, a default-prediction model | SQL Section D, Python §8-9, Excel `Loan_Risk` |
| Reduce fraud losses | Fraud rate/exposure by type & channel | SQL Section C, Python §7, Excel `Data_Fraud`/dashboards |
| Understand merchant/agent network health | Merchant & agent performance, geographic view | SQL Section E, Tableau/Power BI map pages |
| Operational reliability | Transaction lifecycle / failure-reason analysis | SQL Section F |

## How to present this in a portfolio (suggested narrative arc)
1. **The ask** — one sentence: "Built a full-stack analytics solution for a
   fintech's transaction, lending and fraud data."
2. **The data** — 1,000 customers, 3,000+ transactions, 500 loans, 150 fraud
   events across a year of activity (mention it's a realistic, purpose-built
   dataset, not real customer data, if asked).
3. **The approach** — SQL for data modeling/querying → Python for EDA,
   segmentation and a predictive model → BI tools for stakeholder-facing
   dashboards → Excel for the finance/ops audience who still lives in
   spreadsheets.
4. **3-5 headline findings** — pull your own numbers from the notebook/SQL
   output once you've run them, e.g.:
   - "X% of transactions fail/reverse on [channel], costing an estimated
     KES Y in lost fee revenue annually."
   - "PAR90 sits at Z% of the active loan book — [above/within] the ~5-10%
     range typical of digital lenders."
   - "N% of customers are 'At Risk' or 'Dormant' by RFM segment — a targeted
     re-engagement campaign could recover an estimated KES ... in fee revenue."
5. **What you'd do next** — e.g., pull in behavioral features for the default
   model, A/B test a re-engagement campaign on the At Risk segment, investigate
   the highest-failure channel with the ops team.

> Fill in the bracketed numbers above with your own findings after you run the
> Python notebook and SQL — a genuinely reviewed, specific insight is worth far
> more to a hiring manager than a generic dashboard screenshot.
