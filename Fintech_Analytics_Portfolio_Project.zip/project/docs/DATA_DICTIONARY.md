# Data Dictionary — Kenyan Fintech Analytics Project

Source database: `fintech.db` (SQLite). Star-schema CSVs derived from it live in
`/data/star_schema/`. All monetary fields are in **Kenyan Shillings (KES)**.

## ⚠️ Analyst assumptions (documented, not hidden)
- **County names**: the raw database only ships `county_id` (1-15). Real Kenyan
  county names (Nairobi, Mombasa, Kisumu, ...) were mapped on for geographic
  analysis. This mapping is arbitrary/illustrative, not the analyst's claim about
  which literal county each ID represents in a real production system — if this
  were a live project, you would confirm the real mapping with the data owner
  before publishing county-level conclusions externally.
- **Snapshot date**: recency-based metrics (RFM, tenure, "days since last
  transaction") use **2025-12-31** as the "as of" date, matching the last date in
  the transaction log.
- A handful of `transaction_id`s in `fraud_events` had two fraud alerts logged
  against them; the star-schema `fact_transactions` keeps only the
  highest-`risk_score` alert per transaction so the fact table stays at a clean
  one-row-per-transaction grain (see `fact_fraud_events` for the full, un-deduped
  list of every alert).

---

## Dimension tables

### `dim_customer` (1,000 rows) — grain: 1 row per customer
| Column | Type | Description |
|---|---|---|
| customer_id | text (PK) | Unique customer identifier |
| first_name, last_name | text | Customer name |
| gender | text | Male / Female |
| date_of_birth | date | DOB |
| age | int | Derived: age as of 2025-12-31 |
| age_band | text | Derived: 18-24 / 25-34 / 35-44 / 45-54 / 55-64 / 65+ |
| phone_number | int | Phone (Kenyan format, 2547XXXXXXXX) |
| county_id / county_name | int / text | Home county (see assumption above) |
| customer_type | text | Individual / SME |
| occupation | text | e.g. Software Developer, Trader, Farmer |
| income_band | text | 20K-30K, 30K-50K, 50K-100K, 100K-250K, 250K+ (monthly KES) |
| registration_date | date | Account signup date |
| tenure_days | int | Derived: days since registration |
| kyc_status | text | Verified / Pending |
| customer_status | text | Active / Inactive |

### `dim_account` (1,000 rows) — grain: 1 row per account
| Column | Description |
|---|---|
| account_id (PK) | Unique account identifier |
| customer_id (FK) | Owning customer |
| product_id (FK) | Links to dim_product |
| account_number | Account/phone number |
| opened_date | Date account opened |
| account_status | Active / Dormant / Closed |
| current_balance | Wallet balance, KES |
| product_name, product_type | Denormalized from dim_product |

### `dim_product` (7 rows)
Mobile Wallet, Merchant Payments, Bank Transfer, Mobile Credit, Savings Wallet,
Bill Payments, International Transfer — each with a `product_type`
(Payments / Transfers / Credit / Savings / Remittance).

### `dim_merchant` (150 rows) — grain: 1 row per merchant
merchant_id (PK), merchant_name, merchant_category (Pharmacy, Agriculture,
E-commerce, General Retail, Utilities, Telecommunications, Fuel Station,
Electronics, Restaurant, Supermarket, Fashion), county_id/county_name,
registration_date, merchant_status.

### `dim_agent` (100 rows) — grain: 1 row per cash agent
agent_id (PK), agent_name, county_id/county_name, registration_date,
agent_status (Active/Inactive).

### `dim_county` (15 rows)
county_id (PK), county_name.

### `dim_date` (1,096 rows, 2023-01-01 → 2025-12-31)
Standard calendar table: date_key (YYYYMMDD int, PK), date, year, quarter, month,
month_name, month_year, week, weekday_name, weekday_num, is_weekend,
is_month_end. Mark as the "Date Table" in Power BI / use as the calendar axis in
Tableau.

---

## Fact tables

### `fact_transactions` (3,015 rows) — grain: 1 row per transaction
| Column | Description |
|---|---|
| transaction_id (PK) | Unique transaction id |
| account_id, customer_id (FK) | Who transacted |
| date_key (FK) | Links to dim_date |
| transaction_date | Full timestamp |
| transaction_hour | 0-23, derived |
| transaction_type | Payment / Transfer / Bill Payment / Merchant Payment / Withdrawal |
| channel | Mobile / USSD / Agent / App |
| amount_kes, fee_kes | Transaction value and fee charged |
| net_amount_kes | Derived: amount_kes − fee_kes |
| amount_bucket | Derived segmentation: 0-500, 500-2K, 2K-5K, 5K-20K, 20K-50K, 50K+ |
| status | Completed / Failed / Reversed |
| is_successful / is_failed / is_reversed | Derived 0/1 flags |
| recipient_type | Merchant / Individual / Utility / Business |
| merchant_id, agent_id (FK, nullable) | Counterparty, if applicable |
| fraud_type, risk_score, investigation_status | From fraud_events (highest-risk alert if >1) |
| is_flagged_fraud / is_confirmed_fraud | Derived 0/1 flags |

### `fact_loans` (500 rows) — grain: 1 row per loan
loan_id (PK), customer_id (FK), application_date, approval_date, loan_product
(Mobile Credit / Business Loan / Salary Advance), requested_amount,
approved_amount, interest_rate (%), term_days, loan_status (Paid / Active /
Defaulted / Rejected), outstanding_balance, days_past_due, approval_days
(derived), is_defaulted/is_paid (derived), application_date_key (FK to dim_date).

### `fact_loan_repayments` (766 rows) — grain: 1 row per scheduled repayment
repayment_id (PK), loan_id (FK), repayment_date, amount_due, amount_paid,
days_past_due, repayment_status, shortfall (derived: amount_due − amount_paid).

### `fact_fraud_events` (150 rows) — grain: 1 row per fraud alert
fraud_event_id (PK), transaction_id (FK), detected_at, fraud_type (Velocity
anomaly / New beneficiary risk / Multiple failed attempts / Unusual transaction
amount), risk_score (0-1), investigation_status (New / Investigating / Confirmed
/ Closed), confirmed_fraud (0/1).

---

## Other raw tables (not remodeled into the star schema, still in `/data/raw/`)
- `fees` — per-transaction fee detail (fee_type, fee_amount, fee_date)
- `customer_products` — which products each customer is enrolled in
- `beneficiaries` — saved payees per customer
- `transaction_status_history` — full audit trail of every status change per
  transaction, useful for operational/lifecycle analysis (see SQL Section F)
- `customer_360`, `transaction_fee_summary` — pre-aggregated convenience tables
  shipped with the original database (kept for reference / reconciliation checks)
