# Star Schema Diagram

Renders automatically on GitHub/GitLab (Mermaid support). If your portfolio host
doesn't render Mermaid, paste the code block into https://mermaid.live to export
a PNG/SVG.

```mermaid
erDiagram
    dim_customer ||--o{ fact_transactions : "makes"
    dim_customer ||--o{ fact_loans : "applies for"
    dim_account  ||--o{ fact_transactions : "used in"
    dim_product  ||--o{ dim_account : "type of"
    dim_merchant ||--o{ fact_transactions : "receives"
    dim_agent    ||--o{ fact_transactions : "processes"
    dim_county   ||--o{ dim_customer : "resides in"
    dim_county   ||--o{ dim_merchant : "located in"
    dim_county   ||--o{ dim_agent : "located in"
    dim_date     ||--o{ fact_transactions : "occurs on"
    fact_loans   ||--o{ fact_loan_repayments : "repaid via"
    fact_transactions ||--o| fact_fraud_events : "flagged by"

    dim_customer {
        text customer_id PK
        text first_name
        text last_name
        text gender
        int  age
        text income_band
        text kyc_status
        text customer_status
    }
    dim_account {
        text account_id PK
        text customer_id FK
        int  product_id FK
        real current_balance
    }
    dim_product {
        int  product_id PK
        text product_name
        text product_type
    }
    dim_merchant {
        text merchant_id PK
        text merchant_name
        text merchant_category
    }
    dim_agent {
        text agent_id PK
        text agent_name
        text agent_status
    }
    dim_county {
        int  county_id PK
        text county_name
    }
    dim_date {
        int  date_key PK
        date date
        int  year
        int  month
    }
    fact_transactions {
        text transaction_id PK
        text account_id FK
        text customer_id FK
        int  date_key FK
        text merchant_id FK
        text agent_id FK
        real amount_kes
        real fee_kes
        text status
    }
    fact_loans {
        text loan_id PK
        text customer_id FK
        text loan_product
        real approved_amount
        text loan_status
        int  days_past_due
    }
    fact_loan_repayments {
        text repayment_id PK
        text loan_id FK
        real amount_due
        real amount_paid
    }
    fact_fraud_events {
        text fraud_event_id PK
        text transaction_id FK
        text fraud_type
        real risk_score
    }
```

## Model type: Star Schema
- **Fact tables** (transactional/measurable events): `fact_transactions`,
  `fact_loans`, `fact_loan_repayments`, `fact_fraud_events`
- **Dimension tables** (descriptive context): `dim_customer`, `dim_account`,
  `dim_product`, `dim_merchant`, `dim_agent`, `dim_county`, `dim_date`

This is the same modeling pattern used in real fintech data warehouses (and is
exactly what Tableau/Power BI expect for fast, correct aggregation) — one wide,
narrow fact table per business process, surrounded by small reusable dimensions.
