# Power BI — Build Guide
### Kenyan Fintech Analytics Project

This folder contains the same star-schema CSV extracts used for Tableau. Power BI
`.pbix` files are binary and can only be authored inside Power BI Desktop, so this
guide gives you the exact data model and DAX so you can rebuild the report quickly
and it will match the numbers in the SQL/Python/Excel parts of this project.

---

## 1. Install & load data

1. Download **Power BI Desktop** (free): https://powerbi.microsoft.com/desktop/
2. **Get Data > Text/CSV** → import every file in this folder:
   `dim_customer`, `dim_account`, `dim_product`, `dim_merchant`, `dim_agent`,
   `dim_county`, `dim_date`, `fact_transactions`, `fact_loans`,
   `fact_loan_repayments`, `fact_fraud_events`.
3. In **Power Query Editor**, confirm data types: dates as Date, `amount_kes` /
   `fee_kes` / `outstanding_balance` as Decimal Number, IDs as Text.
4. Click **Close & Apply**.

## 2. Build the star-schema data model

Go to **Model view** and create these relationships (drag field to field):

| From | To | Cardinality |
|---|---|---|
| `fact_transactions[customer_id]` | `dim_customer[customer_id]` | Many-to-1 |
| `fact_transactions[account_id]`  | `dim_account[account_id]`   | Many-to-1 |
| `fact_transactions[merchant_id]` | `dim_merchant[merchant_id]` | Many-to-1 |
| `fact_transactions[agent_id]`    | `dim_agent[agent_id]`       | Many-to-1 |
| `fact_transactions[date_key]`    | `dim_date[date_key]`        | Many-to-1 |
| `dim_customer[county_id]`        | `dim_county[county_id]`     | Many-to-1 |
| `dim_merchant[county_id]`        | `dim_county[county_id]`     | Many-to-1 |
| `fact_loans[customer_id]`        | `dim_customer[customer_id]` | Many-to-1 |
| `fact_loan_repayments[loan_id]`  | `fact_loans[loan_id]`       | Many-to-1 |
| `fact_fraud_events[transaction_id]` | `fact_transactions[transaction_id]` | 1-to-1 |

Mark `dim_date` as a **Date Table** (Modeling tab → Mark as Date Table), which
enables time-intelligence DAX functions (`TOTALYTD`, `SAMEPERIODLASTYEAR`, etc.)

## 3. Core DAX measures

Create a dedicated measures table (**New Table** → `Measures = {}` trick, or just
add measures anywhere) and paste these in:

```DAX
Total Transactions = COUNTROWS(fact_transactions)

Completed Transactions =
CALCULATE(COUNTROWS(fact_transactions), fact_transactions[status] = "Completed")

Success Rate % = DIVIDE([Completed Transactions], [Total Transactions])

Failed Transactions =
CALCULATE(COUNTROWS(fact_transactions), fact_transactions[status] = "Failed")

Failure Rate % = DIVIDE([Failed Transactions], [Total Transactions])

Total TPV (KES) =
CALCULATE(SUM(fact_transactions[amount_kes]), fact_transactions[status] = "Completed")

Total Fee Revenue (KES) =
CALCULATE(SUM(fact_transactions[fee_kes]), fact_transactions[status] = "Completed")

Avg Transaction Value (KES) = DIVIDE([Total TPV (KES)], [Completed Transactions])

MoM TPV Growth % =
VAR CurrentTPV = [Total TPV (KES)]
VAR PriorTPV = CALCULATE([Total TPV (KES)], PREVIOUSMONTH(dim_date[date]))
RETURN DIVIDE(CurrentTPV - PriorTPV, PriorTPV)

-- Lending / credit risk
Total Loans Issued = COUNTROWS(fact_loans)

Total Disbursed (KES) =
CALCULATE(SUM(fact_loans[approved_amount]), fact_loans[loan_status] <> "Rejected")

Defaulted Loans =
CALCULATE(COUNTROWS(fact_loans), fact_loans[loan_status] = "Defaulted")

Default Rate % = DIVIDE([Defaulted Loans], [Total Loans Issued])

Outstanding Balance (KES) =
CALCULATE(SUM(fact_loans[outstanding_balance]), fact_loans[loan_status] = "Active")

PAR90 (%) =
VAR NPLBalance =
    CALCULATE(SUM(fact_loans[outstanding_balance]),
              fact_loans[loan_status] = "Active", fact_loans[days_past_due] > 90)
RETURN DIVIDE(NPLBalance, [Outstanding Balance (KES)])

-- Fraud
Fraud Alerts = COUNTROWS(fact_fraud_events)

Confirmed Fraud Cases =
CALCULATE(COUNTROWS(fact_fraud_events), fact_fraud_events[investigation_status] = "Confirmed")

Fraud Exposure (KES) =
CALCULATE(SUM(fact_transactions[amount_kes]), fact_transactions[is_flagged_fraud] = 1)

-- Customer
Active Customers =
CALCULATE(DISTINCTCOUNT(fact_transactions[customer_id]), fact_transactions[status]="Completed")

DPD Risk Bucket =
SWITCH(
    TRUE(),
    fact_loans[days_past_due] = 0, "Current",
    fact_loans[days_past_due] <= 30, "1-30 DPD",
    fact_loans[days_past_due] <= 90, "31-90 DPD",
    "90+ DPD (NPL)"
)
```

> Tip: `DPD Risk Bucket` above is written as a **calculated column** (goes in
> `fact_loans`, referenced with `fact_loans[days_past_due]` row context) rather
> than a measure — add it via **New Column**, not **New Measure**.

## 4. Report pages to build (mirrors the Tableau dashboard so both tools tell
   a consistent story — useful if a job posting asks for either tool)

1. **Executive Overview** — KPI cards (Total TPV, Fee Revenue, Success Rate,
   Active Customers), a line chart of monthly TPV, a clustered bar of revenue by
   transaction type.
2. **Customer Segmentation** — import `customer_rfm_segments.csv` as an extra
   table, connect on `customer_id`; build a scatter (Recency vs Monetary,
   sized by Frequency), a segment donut chart, and a Kenya county map
   (use the **Shape Map** or **ArcGIS Maps** visual with `county_name`).
3. **Fraud & Risk** — fraud alerts by type/status (stacked bar), a card for
   Fraud Exposure (KES), a scatter of risk_score vs amount_kes.
4. **Lending Performance** — PAR90 card, donut of `DPD Risk Bucket`, default
   rate by `loan_product` (bar), monthly disbursement trend (line).

## 5. Formatting & UX
- Apply a single theme: **View > Themes** → pick or import a custom JSON theme
  using the same accent color as your Tableau/Excel work (`#2E86AB`) for a
  consistent personal brand across every deliverable.
- Use **Format > KES currency**: set number format to `"KES" #,##0` on all
  monetary measures.
- Add **slicers** for Year/Month, County, and Channel synced across all pages
  (Format > Edit interactions, or Sync slicers pane).

## 6. Publish (this becomes another live portfolio link)
1. **Home > Publish** → sign in with a free Power BI account → choose "My
   workspace".
2. In the Power BI Service (app.powerbi.com), open the report → **File >
   Publish to web** (or Embed) to get a public, shareable link/embed code
   (Publish to Web makes it fully public — do not use this option if the data
   were sensitive, but this synthetic dataset is safe to share).
3. Add the link to your portfolio site, GitHub README and LinkedIn featured
   section.
