"""
Builds a clean star-schema (dimensional model) from the raw fintech.db tables.
Outputs CSVs to data/star_schema/ for use in SQL, Python, Excel, Tableau and Power BI.
"""
import sqlite3
import pandas as pd
import numpy as np

conn = sqlite3.connect('/mnt/user-data/uploads/1788646957597_fintech.db')

# ---------------------------------------------------------------
# County reference (dataset ships only county_id -> enrich with
# real Kenyan county names for geographic analysis). This mapping
# is an ANALYST ASSUMPTION documented in docs/data_dictionary.md
# ---------------------------------------------------------------
county_map = {
    1: "Nairobi", 2: "Mombasa", 3: "Kisumu", 4: "Nakuru", 5: "Uasin Gishu",
    6: "Kiambu", 7: "Machakos", 8: "Kajiado", 9: "Nyeri", 10: "Meru",
    11: "Kakamega", 12: "Bungoma", 13: "Kilifi", 14: "Garissa", 15: "Kisii"
}
dim_county = pd.DataFrame({"county_id": list(county_map.keys()), "county_name": list(county_map.values())})
dim_county.to_csv("/home/claude/project/data/star_schema/dim_county.csv", index=False)

# ---------------------------------------------------------------
# DIM CUSTOMER
# ---------------------------------------------------------------
customers = pd.read_sql("SELECT * FROM customers", conn, parse_dates=["date_of_birth", "registration_date"])
customers["age"] = ((pd.Timestamp("2025-12-31") - customers["date_of_birth"]).dt.days // 365).astype(int)
bins = [0, 24, 34, 44, 54, 64, 120]
labels = ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"]
customers["age_band"] = pd.cut(customers["age"], bins=bins, labels=labels)
customers = customers.merge(dim_county, on="county_id", how="left")
customers["tenure_days"] = (pd.Timestamp("2025-12-31") - customers["registration_date"]).dt.days
dim_customer = customers[[
    "customer_id","first_name","last_name","gender","date_of_birth","age","age_band",
    "phone_number","county_id","county_name","customer_type","occupation","income_band",
    "registration_date","tenure_days","kyc_status","customer_status"
]]
dim_customer.to_csv("/home/claude/project/data/star_schema/dim_customer.csv", index=False)

# ---------------------------------------------------------------
# DIM PRODUCT
# ---------------------------------------------------------------
products = pd.read_sql("SELECT * FROM products", conn)
products.to_csv("/home/claude/project/data/star_schema/dim_product.csv", index=False)

# ---------------------------------------------------------------
# DIM ACCOUNT
# ---------------------------------------------------------------
accounts = pd.read_sql("SELECT * FROM accounts", conn, parse_dates=["opened_date"])
accounts = accounts.merge(products[["product_id","product_name","product_type"]], on="product_id", how="left")
accounts.to_csv("/home/claude/project/data/star_schema/dim_account.csv", index=False)

# ---------------------------------------------------------------
# DIM MERCHANT
# ---------------------------------------------------------------
merchants = pd.read_sql("SELECT * FROM merchants", conn, parse_dates=["registration_date"])
merchants = merchants.merge(dim_county, on="county_id", how="left")
merchants.to_csv("/home/claude/project/data/star_schema/dim_merchant.csv", index=False)

# ---------------------------------------------------------------
# DIM AGENT
# ---------------------------------------------------------------
agents = pd.read_sql("SELECT * FROM agents", conn, parse_dates=["registration_date"])
agents = agents.merge(dim_county, on="county_id", how="left")
agents.to_csv("/home/claude/project/data/star_schema/dim_agent.csv", index=False)

# ---------------------------------------------------------------
# DIM DATE  (covers full transaction date range with buffer)
# ---------------------------------------------------------------
date_range = pd.date_range("2023-01-01", "2025-12-31", freq="D")
dim_date = pd.DataFrame({"date": date_range})
dim_date["date_key"] = dim_date["date"].dt.strftime("%Y%m%d").astype(int)
dim_date["year"] = dim_date["date"].dt.year
dim_date["quarter"] = dim_date["date"].dt.quarter
dim_date["month"] = dim_date["date"].dt.month
dim_date["month_name"] = dim_date["date"].dt.strftime("%B")
dim_date["month_year"] = dim_date["date"].dt.strftime("%b-%Y")
dim_date["week"] = dim_date["date"].dt.isocalendar().week
dim_date["weekday_name"] = dim_date["date"].dt.strftime("%A")
dim_date["weekday_num"] = dim_date["date"].dt.weekday
dim_date["is_weekend"] = dim_date["weekday_num"].isin([5, 6])
dim_date["is_month_end"] = dim_date["date"].dt.is_month_end
dim_date = dim_date[["date_key","date","year","quarter","month","month_name","month_year",
                     "week","weekday_name","weekday_num","is_weekend","is_month_end"]]
dim_date.to_csv("/home/claude/project/data/star_schema/dim_date.csv", index=False)

# ---------------------------------------------------------------
# FACT TRANSACTIONS  (grain: one row per transaction)
# ---------------------------------------------------------------
txn = pd.read_sql("SELECT * FROM transactions", conn, parse_dates=["transaction_date"])
txn["date_key"] = txn["transaction_date"].dt.strftime("%Y%m%d").astype(int)
txn["transaction_hour"] = txn["transaction_date"].dt.hour
txn["is_successful"] = (txn["status"] == "Completed").astype(int)
txn["is_failed"] = (txn["status"] == "Failed").astype(int)
txn["is_reversed"] = (txn["status"] == "Reversed").astype(int)
txn["net_amount_kes"] = txn["amount_kes"] - txn["fee_kes"].fillna(0)

# amount bucket for segmentation
def bucket(a):
    if a < 500: return "0-500"
    if a < 2000: return "500-2K"
    if a < 5000: return "2K-5K"
    if a < 20000: return "5K-20K"
    if a < 50000: return "20K-50K"
    return "50K+"
txn["amount_bucket"] = txn["amount_kes"].apply(bucket)

# flag fraud-linked transactions (a few transactions have 2 fraud_events rows;
# keep the highest-risk record per transaction to preserve the 1-row-per-transaction grain)
fraud = pd.read_sql("SELECT transaction_id, fraud_type, risk_score, investigation_status, confirmed_fraud FROM fraud_events", conn)
fraud = fraud.sort_values("risk_score", ascending=False).drop_duplicates("transaction_id", keep="first")
txn = txn.merge(fraud, on="transaction_id", how="left")
txn["is_flagged_fraud"] = txn["fraud_type"].notna().astype(int)
txn["is_confirmed_fraud"] = txn["confirmed_fraud"].fillna(0).astype(int)

fact_transactions = txn[[
    "transaction_id","account_id","customer_id","date_key","transaction_date","transaction_hour",
    "transaction_type","channel","amount_kes","fee_kes","net_amount_kes","amount_bucket","status",
    "is_successful","is_failed","is_reversed","reference_number","recipient_type","merchant_id",
    "agent_id","fraud_type","risk_score","investigation_status","is_flagged_fraud","is_confirmed_fraud"
]]
fact_transactions.to_csv("/home/claude/project/data/star_schema/fact_transactions.csv", index=False)

# ---------------------------------------------------------------
# FACT LOANS  (grain: one row per loan)
# ---------------------------------------------------------------
loans = pd.read_sql("SELECT * FROM loans", conn, parse_dates=["application_date","approval_date"])
loans["approval_days"] = (loans["approval_date"] - loans["application_date"]).dt.days
loans["is_defaulted"] = (loans["loan_status"] == "Defaulted").astype(int)
loans["is_paid"] = (loans["loan_status"] == "Paid").astype(int)
loans["application_date_key"] = loans["application_date"].dt.strftime("%Y%m%d").astype(int)
loans.to_csv("/home/claude/project/data/star_schema/fact_loans.csv", index=False)

# ---------------------------------------------------------------
# FACT LOAN REPAYMENTS
# ---------------------------------------------------------------
repay = pd.read_sql("SELECT * FROM loan_repayments", conn, parse_dates=["repayment_date"])
repay["date_key"] = repay["repayment_date"].dt.strftime("%Y%m%d").astype(int)
repay["shortfall"] = repay["amount_due"] - repay["amount_paid"]
repay.to_csv("/home/claude/project/data/star_schema/fact_loan_repayments.csv", index=False)

# ---------------------------------------------------------------
# FACT FRAUD EVENTS
# ---------------------------------------------------------------
fraud_full = pd.read_sql("SELECT * FROM fraud_events", conn, parse_dates=["detected_at"])
fraud_full["date_key"] = fraud_full["detected_at"].dt.strftime("%Y%m%d").astype(int)
fraud_full.to_csv("/home/claude/project/data/star_schema/fact_fraud_events.csv", index=False)

print("Star schema build complete.")
for f in ["dim_county","dim_customer","dim_product","dim_account","dim_merchant","dim_agent",
          "dim_date","fact_transactions","fact_loans","fact_loan_repayments","fact_fraud_events"]:
    df = pd.read_csv(f"/home/claude/project/data/star_schema/{f}.csv")
    print(f"{f}: {df.shape}")
conn.close()
