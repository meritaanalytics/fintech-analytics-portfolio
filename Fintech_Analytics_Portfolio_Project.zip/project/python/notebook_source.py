# %% [markdown]
# # Kenyan Fintech Analytics — Full Data Analyst Portfolio Project
#
# **Dataset:** `fintech.db` — a mobile-money / digital-lending platform (M-Pesa-style)
# with 1,000 customers, 3,015 transactions, 500 loans, 150 fraud events, 150 merchants
# and 100 agents across 15 Kenyan counties.
#
# **What this notebook demonstrates (core data analyst / fintech skills):**
# 1. Connecting to a SQL database from Python & running SQL from pandas
# 2. Data cleaning & data-quality auditing
# 3. Exploratory Data Analysis (EDA) with visualizations
# 4. Customer segmentation — RFM analysis
# 5. Cohort retention analysis
# 6. Fraud analytics
# 7. Credit risk / lending analytics (Portfolio-at-Risk)
# 8. A predictive model: loan default prediction (Logistic Regression + Random Forest)
# 9. Exporting clean, modeled data for Excel / Tableau / Power BI
#
# **Author:** *(add your name here before publishing)*

# %%
import sqlite3
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (classification_report, roc_auc_score, roc_curve,
                              confusion_matrix, ConfusionMatrixDisplay)

sns.set_theme(style="whitegrid", palette="viridis")
plt.rcParams["figure.figsize"] = (10, 5)
pd.set_option("display.max_columns", None)

DB_PATH = "../data/fintech.db"   # adjust path if you moved the .db file
conn = sqlite3.connect(DB_PATH)

# %% [markdown]
# ## 1. Load data

# %%
customers    = pd.read_sql("SELECT * FROM customers", conn, parse_dates=["date_of_birth", "registration_date"])
accounts     = pd.read_sql("SELECT * FROM accounts", conn, parse_dates=["opened_date"])
transactions = pd.read_sql("SELECT * FROM transactions", conn, parse_dates=["transaction_date"])
loans        = pd.read_sql("SELECT * FROM loans", conn, parse_dates=["application_date", "approval_date"])
repayments   = pd.read_sql("SELECT * FROM loan_repayments", conn, parse_dates=["repayment_date"])
fraud        = pd.read_sql("SELECT * FROM fraud_events", conn, parse_dates=["detected_at"])
merchants    = pd.read_sql("SELECT * FROM merchants", conn, parse_dates=["registration_date"])
agents       = pd.read_sql("SELECT * FROM agents", conn, parse_dates=["registration_date"])
products     = pd.read_sql("SELECT * FROM products", conn)

print("Row counts:")
for name, df in [("customers", customers), ("accounts", accounts), ("transactions", transactions),
                  ("loans", loans), ("repayments", repayments), ("fraud", fraud),
                  ("merchants", merchants), ("agents", agents)]:
    print(f"  {name:15s}: {len(df):,}")

# %% [markdown]
# ## 2. Data quality audit
#
# A real analyst never trusts a dataset blindly. We check for nulls, duplicates,
# referential-integrity issues and outliers before computing a single KPI.

# %%
print("Missing values per table (only columns with any nulls shown):\n")
for name, df in [("customers", customers), ("transactions", transactions), ("loans", loans)]:
    miss = df.isna().sum()
    miss = miss[miss > 0]
    print(f"--- {name} ---")
    print(miss if len(miss) else "  (no missing values)")
    print()

# Duplicate transaction IDs
dupes = transactions["transaction_id"].duplicated().sum()
print(f"Duplicate transaction_ids: {dupes}")

# Orphan transactions (account not in accounts table)
orphans = transactions[~transactions["account_id"].isin(accounts["account_id"])]
print(f"Orphan transactions (no matching account): {len(orphans)}")

# Outlier check on transaction amount
print("\nTransaction amount (KES) distribution:")
print(transactions["amount_kes"].describe())

# %% [markdown]
# ## 3. Feature engineering
#
# Enrich raw tables with derived fields used throughout the analysis: age,
# tenure, county names, transaction hour/weekday, fraud flags.

# %%
county_map = {
    1: "Nairobi", 2: "Mombasa", 3: "Kisumu", 4: "Nakuru", 5: "Uasin Gishu",
    6: "Kiambu", 7: "Machakos", 8: "Kajiado", 9: "Nyeri", 10: "Meru",
    11: "Kakamega", 12: "Bungoma", 13: "Kilifi", 14: "Garissa", 15: "Kisii"
}
customers["county_name"] = customers["county_id"].map(county_map)
customers["age"] = ((pd.Timestamp("2025-12-31") - customers["date_of_birth"]).dt.days // 365)
customers["tenure_days"] = (pd.Timestamp("2025-12-31") - customers["registration_date"]).dt.days

transactions["txn_hour"]     = transactions["transaction_date"].dt.hour
transactions["txn_weekday"]  = transactions["transaction_date"].dt.day_name()
transactions["txn_month"]    = transactions["transaction_date"].dt.to_period("M").astype(str)
transactions["is_successful"] = (transactions["status"] == "Completed").astype(int)

fraud_dedup = fraud.sort_values("risk_score", ascending=False).drop_duplicates("transaction_id")
transactions = transactions.merge(
    fraud_dedup[["transaction_id", "fraud_type", "risk_score", "investigation_status"]],
    on="transaction_id", how="left"
)
transactions["is_flagged_fraud"] = transactions["fraud_type"].notna().astype(int)

customers.head()

# %% [markdown]
# ## 4. Exploratory Data Analysis (EDA)
#
# ### 4.1 Monthly Total Processing Value (TPV) trend

# %%
monthly = (transactions[transactions.status == "Completed"]
           .groupby("txn_month")
           .agg(tpv_kes=("amount_kes", "sum"), transactions=("transaction_id", "count"),
                fee_revenue=("fee_kes", "sum"))
           .reset_index())

fig, ax1 = plt.subplots(figsize=(12, 5))
ax1.bar(monthly["txn_month"], monthly["tpv_kes"] / 1e6, color="#2E86AB", alpha=0.85, label="TPV (KES millions)")
ax1.set_ylabel("TPV (KES, millions)")
ax1.set_xlabel("Month")
ax1.tick_params(axis="x", rotation=60)
ax2 = ax1.twinx()
ax2.plot(monthly["txn_month"], monthly["fee_revenue"] / 1e3, color="#F24236", marker="o", label="Fee revenue (KES '000)")
ax2.set_ylabel("Fee revenue (KES, thousands)")
fig.suptitle("Monthly Total Processing Value & Fee Revenue", fontsize=13, fontweight="bold")
fig.legend(loc="upper left", bbox_to_anchor=(0.08, 0.9))
plt.tight_layout()
plt.savefig("../docs/charts/01_monthly_tpv.png", dpi=120, bbox_inches="tight")
plt.show()

# %% [markdown]
# ### 4.2 Transaction mix by type and channel

# %%
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
type_mix = transactions.groupby("transaction_type")["amount_kes"].sum().sort_values(ascending=False)
sns.barplot(x=type_mix.values / 1e6, y=type_mix.index, ax=axes[0], palette="mako")
axes[0].set_title("TPV by Transaction Type (KES millions)")
axes[0].set_xlabel("KES (millions)")

channel_mix = transactions["channel"].value_counts()
axes[1].pie(channel_mix.values, labels=channel_mix.index, autopct="%1.1f%%",
            colors=sns.color_palette("mako", len(channel_mix)))
axes[1].set_title("Transaction Volume Share by Channel")
plt.tight_layout()
plt.savefig("../docs/charts/02_type_channel_mix.png", dpi=120, bbox_inches="tight")
plt.show()

# %% [markdown]
# ### 4.3 Success / failure / reversal rate by channel (ops health)

# %%
status_by_channel = pd.crosstab(transactions["channel"], transactions["status"], normalize="index") * 100
status_by_channel.plot(kind="bar", stacked=True, figsize=(9, 5), colormap="RdYlGn_r")
plt.title("Transaction Outcome Rate by Channel (%)", fontweight="bold")
plt.ylabel("% of transactions")
plt.xticks(rotation=0)
plt.legend(title="Status")
plt.tight_layout()
plt.savefig("../docs/charts/03_status_by_channel.png", dpi=120, bbox_inches="tight")
plt.show()
status_by_channel.round(1)

# %% [markdown]
# ### 4.4 Peak hours heatmap (hour vs weekday) — infra & staffing insight

# %%
heat = transactions.pivot_table(index="txn_weekday", columns="txn_hour",
                                 values="transaction_id", aggfunc="count", fill_value=0)
weekday_order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
heat = heat.reindex(weekday_order)
plt.figure(figsize=(14, 5))
sns.heatmap(heat, cmap="rocket_r", cbar_kws={"label": "Transaction count"})
plt.title("Transaction Volume Heatmap: Hour of Day vs Day of Week", fontweight="bold")
plt.xlabel("Hour of day")
plt.ylabel("")
plt.tight_layout()
plt.savefig("../docs/charts/04_hour_weekday_heatmap.png", dpi=120, bbox_inches="tight")
plt.show()

# %% [markdown]
# ## 5. Customer Segmentation — RFM Analysis
#
# RFM = **R**ecency (days since last transaction), **F**requency (number of
# transactions), **M**onetary (total value transacted). This is one of the
# most requested fintech/marketing analytics techniques.

# %%
snapshot_date = pd.Timestamp("2025-12-31")
completed = transactions[transactions.status == "Completed"]

rfm = completed.groupby("customer_id").agg(
    recency_days=("transaction_date", lambda x: (snapshot_date - x.max()).days),
    frequency=("transaction_id", "count"),
    monetary=("amount_kes", "sum")
).reset_index()

rfm["R"] = pd.qcut(rfm["recency_days"], 5, labels=[5, 4, 3, 2, 1]).astype(int)
rfm["F"] = pd.qcut(rfm["frequency"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["M"] = pd.qcut(rfm["monetary"], 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["RFM_score"] = rfm["R"] + rfm["F"] + rfm["M"]

def segment(row):
    if row.R >= 4 and row.F >= 4 and row.M >= 4:
        return "Champions"
    if row.R >= 3 and row.F >= 3:
        return "Loyal Customers"
    if row.R >= 4 and row.F <= 2:
        return "New / Promising"
    if row.R <= 2 and row.F >= 3:
        return "At Risk"
    if row.R <= 2 and row.F <= 2:
        return "Dormant / Churned"
    return "Needs Attention"

rfm["segment"] = rfm.apply(segment, axis=1)

plt.figure(figsize=(9, 5))
seg_counts = rfm["segment"].value_counts()
sns.barplot(x=seg_counts.values, y=seg_counts.index, palette="viridis")
plt.title("Customer RFM Segments", fontweight="bold")
plt.xlabel("Number of customers")
plt.tight_layout()
plt.savefig("../docs/charts/05_rfm_segments.png", dpi=120, bbox_inches="tight")
plt.show()
rfm.groupby("segment")[["recency_days", "frequency", "monetary"]].mean().round(1)

# %% [markdown]
# ## 6. Cohort Retention Analysis
#
# Group customers by the month they registered, then track what % of each
# cohort is still transacting in subsequent months — a core retention KPI.

# %%
cust_cohort = customers[["customer_id"]].copy()
cust_cohort["cohort_month"] = customers["registration_date"].dt.to_period("M")

txn_activity = completed[["customer_id", "transaction_date"]].copy()
txn_activity["activity_month"] = txn_activity["transaction_date"].dt.to_period("M")
txn_activity = txn_activity.merge(cust_cohort, on="customer_id")
txn_activity["month_number"] = (txn_activity["activity_month"] - txn_activity["cohort_month"]).apply(lambda x: x.n)

cohort_counts = (txn_activity.groupby(["cohort_month", "month_number"])["customer_id"]
                  .nunique().reset_index())
cohort_pivot = cohort_counts.pivot(index="cohort_month", columns="month_number", values="customer_id")
cohort_size = cohort_pivot[0]
retention = cohort_pivot.divide(cohort_size, axis=0) * 100

plt.figure(figsize=(13, 6))
sns.heatmap(retention.iloc[:, :12], annot=True, fmt=".0f", cmap="YlGnBu", cbar_kws={"label": "% retained"})
plt.title("Monthly Cohort Retention (%)", fontweight="bold")
plt.xlabel("Months since registration")
plt.ylabel("Registration cohort")
plt.tight_layout()
plt.savefig("../docs/charts/06_cohort_retention.png", dpi=120, bbox_inches="tight")
plt.show()

# %% [markdown]
# ## 7. Fraud Analytics
#
# ### 7.1 Fraud rate, exposure and type breakdown

# %%
fraud_txn = fraud.merge(transactions[["transaction_id", "amount_kes", "channel", "transaction_type"]],
                         on="transaction_id", how="left")

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fraud_type_counts = fraud_txn["fraud_type"].value_counts()
sns.barplot(x=fraud_type_counts.values, y=fraud_type_counts.index, ax=axes[0], palette="rocket")
axes[0].set_title("Fraud Alerts by Type")
axes[0].set_xlabel("Number of alerts")

exposure = fraud_txn.groupby("fraud_type")["amount_kes"].sum().sort_values(ascending=False)
sns.barplot(x=exposure.values / 1e3, y=exposure.index, ax=axes[1], palette="rocket")
axes[1].set_title("Fraud Exposure by Type (KES '000)")
axes[1].set_xlabel("KES (thousands)")
plt.tight_layout()
plt.savefig("../docs/charts/07_fraud_analysis.png", dpi=120, bbox_inches="tight")
plt.show()

print(f"Total fraud alerts: {len(fraud)}")
print(f"Confirmed fraud cases: {(fraud.investigation_status == 'Confirmed').sum()}")
print(f"Total exposure flagged: KES {fraud_txn['amount_kes'].sum():,.0f}")

# %% [markdown]
# ## 8. Credit Risk — Portfolio at Risk (PAR)

# %%
def risk_bucket(dpd):
    if dpd == 0: return "Current"
    if dpd <= 30: return "1-30 DPD"
    if dpd <= 90: return "31-90 DPD"
    return "90+ DPD (NPL)"

active_loans = loans[loans.loan_status == "Active"].copy()
active_loans["risk_bucket"] = active_loans["days_past_due"].apply(risk_bucket)

par = active_loans.groupby("risk_bucket")["outstanding_balance"].sum().reindex(
    ["Current", "1-30 DPD", "31-90 DPD", "90+ DPD (NPL)"]).fillna(0)

plt.figure(figsize=(8, 8))
colors = ["#2ECC71", "#F1C40F", "#E67E22", "#E74C3C"]
plt.pie(par.values, labels=par.index, autopct="%1.1f%%", colors=colors, startangle=90)
plt.title("Portfolio at Risk (PAR) — Outstanding Balance by DPD Bucket", fontweight="bold")
plt.tight_layout()
plt.savefig("../docs/charts/08_portfolio_at_risk.png", dpi=120, bbox_inches="tight")
plt.show()

par_pct_90plus = par["90+ DPD (NPL)"] / par.sum() * 100
print(f"PAR90 (non-performing loan ratio): {par_pct_90plus:.2f}% of active outstanding balance")

# %% [markdown]
# ## 9. Predictive Model: Loan Default Prediction
#
# We build a binary classifier to predict whether a loan will default,
# using loan-application features known at/near approval time. This is a
# common fintech data-science task: pre-screening credit risk.

# %%
loan_model = loans.merge(customers[["customer_id", "age", "income_band", "occupation",
                                     "customer_type", "kyc_status"]], on="customer_id", how="left")
loan_model = loan_model[loan_model.loan_status.isin(["Paid", "Defaulted"])].copy()
loan_model["target_default"] = (loan_model.loan_status == "Defaulted").astype(int)
loan_model["approval_ratio"] = loan_model["approved_amount"] / loan_model["requested_amount"]

features_num = ["approved_amount", "interest_rate", "term_days", "approval_ratio", "age"]
features_cat = ["loan_product", "income_band", "occupation", "customer_type", "kyc_status"]

X = loan_model[features_num + features_cat]
y = loan_model["target_default"]

print(f"Training rows: {len(X)}  |  Default rate: {y.mean()*100:.1f}%")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

preprocess = ColumnTransformer([
    ("num", StandardScaler(), features_num),
    ("cat", OneHotEncoder(handle_unknown="ignore"), features_cat)
])

log_reg = Pipeline([("prep", preprocess), ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
rf      = Pipeline([("prep", preprocess), ("clf", RandomForestClassifier(n_estimators=300, max_depth=6,
                                                                          class_weight="balanced", random_state=42))])

log_reg.fit(X_train, y_train)
rf.fit(X_train, y_train)

for name, model in [("Logistic Regression", log_reg), ("Random Forest", rf)]:
    proba = model.predict_proba(X_test)[:, 1]
    pred = model.predict(X_test)
    auc = roc_auc_score(y_test, proba)
    print(f"\n=== {name} ===  AUC: {auc:.3f}")
    print(classification_report(y_test, pred, target_names=["Paid", "Defaulted"]))

# %% [markdown]
# ### 9.1 ROC curve comparison & confusion matrix

# %%
fig, axes = plt.subplots(1, 2, figsize=(13, 5))
for name, model, color in [("Logistic Regression", log_reg, "#2E86AB"), ("Random Forest", rf, "#F24236")]:
    proba = model.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, proba)
    axes[0].plot(fpr, tpr, label=f"{name} (AUC={roc_auc_score(y_test, proba):.2f})", color=color, linewidth=2)
axes[0].plot([0, 1], [0, 1], "k--", alpha=0.4)
axes[0].set_xlabel("False Positive Rate"); axes[0].set_ylabel("True Positive Rate")
axes[0].set_title("ROC Curve: Loan Default Prediction")
axes[0].legend()

cm = confusion_matrix(y_test, rf.predict(X_test))
ConfusionMatrixDisplay(cm, display_labels=["Paid", "Defaulted"]).plot(ax=axes[1], cmap="Blues", colorbar=False)
axes[1].set_title("Random Forest — Confusion Matrix")
plt.tight_layout()
plt.savefig("../docs/charts/09_default_model_performance.png", dpi=120, bbox_inches="tight")
plt.show()

# %% [markdown]
# ### 9.2 Feature importance (Random Forest)

# %%
ohe_cols = rf.named_steps["prep"].named_transformers_["cat"].get_feature_names_out(features_cat)
all_features = features_num + list(ohe_cols)
importances = pd.Series(rf.named_steps["clf"].feature_importances_, index=all_features).sort_values(ascending=False).head(15)

plt.figure(figsize=(9, 6))
sns.barplot(x=importances.values, y=importances.index, palette="mako")
plt.title("Top 15 Feature Importances — Loan Default Model", fontweight="bold")
plt.xlabel("Importance")
plt.tight_layout()
plt.savefig("../docs/charts/10_feature_importance.png", dpi=120, bbox_inches="tight")
plt.show()

# %% [markdown]
# ## 10. Export clean, modeled datasets for Excel / Tableau / Power BI
#
# These CSVs feed straight into the Excel workbook, Tableau, and Power BI
# parts of this project (see the `/excel`, `/tableau`, `/powerbi` folders).

# %%
rfm.to_csv("../data/star_schema/customer_rfm_segments.csv", index=False)
retention.to_csv("../data/star_schema/cohort_retention_matrix.csv")
par.to_csv("../data/star_schema/portfolio_at_risk_summary.csv")

loan_model["predicted_default_proba"] = rf.predict_proba(X)[:, 1]
loan_model[["loan_id", "customer_id", "loan_product", "approved_amount", "loan_status",
            "predicted_default_proba"]].to_csv("../data/star_schema/loan_default_predictions.csv", index=False)

print("Exports complete:")
print(" - customer_rfm_segments.csv")
print(" - cohort_retention_matrix.csv")
print(" - portfolio_at_risk_summary.csv")
print(" - loan_default_predictions.csv")

conn.close()

# %% [markdown]
# ## 11. Key Takeaways (fill in with your own written insights before publishing)
#
# - **Growth:** Describe the TPV/revenue trend you found.
# - **Channel risk:** Which channel has the highest failure/reversal rate, and what would you recommend?
# - **Customer segments:** What % of customers are "Champions" vs "At Risk"? What would you do about the At Risk segment?
# - **Fraud:** Which fraud type carries the highest KES exposure? Where should the fraud team focus?
# - **Credit risk:** What is PAR90? Is it within a healthy range (industry benchmark: <5-10% for digital lenders)?
# - **Model:** Which model performed best (AUC) and which features drive default risk the most?
