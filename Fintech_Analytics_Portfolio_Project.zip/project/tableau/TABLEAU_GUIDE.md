# Tableau Public — Build Guide
### Kenyan Fintech Analytics Project

This folder contains the CSV extracts (star schema) to connect directly in Tableau
Desktop or **Tableau Public** (free, and the only version you need to publish a
portfolio piece). Tableau project files (`.twbx`) can't be authored outside the
Tableau application itself, so this guide gives you the exact steps, fields and
calculated-field formulas to reproduce a professional dashboard in under an hour.

---

## 1. Install & connect

1. Download **Tableau Public Desktop** (free): https://public.tableau.com/en-us/s/download
2. Open Tableau Public → **Connect > Text File** → select `fact_transactions.csv`.
3. Drag in the other files and set up relationships (Tableau's modern "relationships",
   not old-style joins) on these keys:

| Table | Join key | Relates to |
|---|---|---|
| `fact_transactions` | `customer_id` | `dim_customer.customer_id` |
| `fact_transactions` | `account_id`  | `dim_account.account_id` |
| `fact_transactions` | `merchant_id` | `dim_merchant.merchant_id` |
| `fact_transactions` | `agent_id`    | `dim_agent.agent_id` |
| `fact_transactions` | `date_key`    | `dim_date.date_key` |
| `dim_customer`      | `county_id`   | `dim_county.county_id` |
| `fact_loans`         | `customer_id` | `dim_customer.customer_id` |
| `fact_fraud_events`  | `transaction_id` | `fact_transactions.transaction_id` |

4. Set `amount_kes`, `fee_kes`, `net_amount_kes` as **Measures**; everything else
   (`customer_id`, `channel`, `status`, county names, etc.) as **Dimensions**.
5. Change `transaction_date` and `date` (in dim_date) to the **Date** data type if
   Tableau doesn't auto-detect it.

---

## 2. Calculated fields to create

Right-click in the Data pane → **Create Calculated Field** for each of the following
(these mirror the KPI logic used in the SQL and Python modules, so all three tools
tell the same story):

```
// Success Rate
Success Rate = SUM(IF [status] = "Completed" THEN 1 ELSE 0 END) / COUNT([transaction_id])

// Failure Rate
Failure Rate = SUM(IF [status] = "Failed" THEN 1 ELSE 0 END) / COUNT([transaction_id])

// Reversal Rate
Reversal Rate = SUM(IF [status] = "Reversed" THEN 1 ELSE 0 END) / COUNT([transaction_id])

// Net Revenue (fees only count when the transaction actually completed)
Completed Fee Revenue = IF [status] = "Completed" THEN [fee_kes] END

// DPD Risk Bucket (for fact_loans)
DPD Risk Bucket =
IF [days_past_due] = 0 THEN "Current"
ELSEIF [days_past_due] <= 30 THEN "1-30 DPD"
ELSEIF [days_past_due] <= 90 THEN "31-90 DPD"
ELSE "90+ DPD (NPL)"
END

// Fraud Flag (Yes/No, for filters and color)
Fraud Flag = IF ISNULL([fraud_type]) THEN "Not Flagged" ELSE "Flagged" END

// Customer Age Band already exists as dim_customer.age_band — use directly

// Month-over-Month TPV Growth (table calculation)
MoM TPV Growth % = (ZN(SUM([amount_kes])) - LOOKUP(ZN(SUM([amount_kes])), -1))
                    / ABS(LOOKUP(ZN(SUM([amount_kes])), -1))
-- set the "Compute Using" to Month(date)
```

---

## 3. Dashboards to build (4 sheets → 1 dashboard, portfolio-ready)

### Sheet 1 — "Executive Overview"
- **KPI cards** (use Text tables or BANs — Big Ass Numbers): Total TPV, Fee Revenue,
  Success Rate, Active Customers. Format `amount_kes` as a custom number format
  `KES #,##0`.
- **Line chart**: `SUM(amount_kes)` over `MONTH(transaction_date)`, colored by
  `transaction_type`.
- **Bar chart**: `Success Rate`, `Failure Rate`, `Reversal Rate` by `channel`.

### Sheet 2 — "Customer & RFM Segmentation"
- Load `customer_rfm_segments.csv` as an additional data source (or blend on
  `customer_id`).
- **Scatter plot**: Recency (x) vs Monetary (y), sized by Frequency, colored by
  `segment`.
- **Treemap**: segment → customer count.
- **Map**: county-level customer count / TPV using `dim_county` + `dim_customer`
  (Tableau will auto-geocode Kenyan county names — if it doesn't recognize a name,
  right-click the mark → Edit Locations and manually set lat/long, or use
  `county_id` as a custom geocoding role).

### Sheet 3 — "Fraud & Risk"
- **Bar chart**: fraud alerts by `fraud_type`, colored by `investigation_status`.
- **Bubble/scatter**: `risk_score` vs `amount_kes` for flagged transactions.
- **PAR donut chart**: outstanding balance by `DPD Risk Bucket` (from `fact_loans`).

### Sheet 4 — "Lending Performance"
- **Bar chart**: default rate by `loan_product`.
- **Line chart**: monthly loan disbursement (`approved_amount` by
  `application_date` month).
- **Highlight table**: default rate by `income_band` (join `fact_loans` to
  `dim_customer`).

### Combine into one Dashboard
- Use a **Dashboard** (not just sheets) sized 1366×768 (Tableau Public default).
- Add a title, a top filter action (e.g., Year, County) that applies across all
  4 sheets via **Use as Filter**.
- Add your name / "Portfolio Project" as a footer caption.

---

## 4. Formatting tips for a portfolio-quality look
- Use a consistent color palette across every sheet (Format > Workbook Theme, or
  manually pick 1 accent color, e.g. `#2E86AB`, plus a neutral gray).
- Turn off gridlines (Format > Lines > Grid Lines > None) for a cleaner look.
- Add tooltips with context, not just raw numbers (`Customer <customer_id> spent
  KES <amount_kes> on <MMM d, yyyy>`).
- Use "KES" as the currency prefix on every number field (Format > Numbers >
  Currency (Custom) → prefix `KES `).

---

## 5. Publish to Tableau Public (this becomes your live portfolio link)
1. **File > Save to Tableau Public As...**
2. Sign in / create a free Tableau Public account.
3. Give the workbook a clear title: *"Kenyan Fintech Analytics: Mobile Money,
   Lending & Fraud Risk"*.
4. Once uploaded, Tableau Public gives you a shareable URL
   (`https://public.tableau.com/app/profile/<you>/viz/<workbook>`) and an embed
   code — put both in your portfolio site and LinkedIn.
5. Add a description under the viz: dataset summary, tools used (SQL, Python,
   Excel, Tableau, Power BI), and 2-3 key insights you found.
