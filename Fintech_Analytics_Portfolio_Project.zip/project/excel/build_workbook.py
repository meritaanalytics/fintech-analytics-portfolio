"""
Builds Fintech_Analyst_Workbook.xlsx — a formula-driven Excel deliverable
demonstrating core spreadsheet analyst skills: SUMIFS/COUNTIFS/AVERAGEIFS,
lookups, pivot-style summary tables, and native Excel charts.
"""
import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule

FONT = "Calibri"
NAVY = "1F3864"
BLUE = "2E86AB"
LIGHT = "D9E2F3"
WHITE = "FFFFFF"

wb = Workbook()

def style_header(ws, row, ncols, fill=NAVY, font_color=WHITE):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = Font(name=FONT, bold=True, color=font_color, size=11)
        cell.fill = PatternFill("solid", fgColor=fill)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = Border(bottom=Side(style="thin", color="000000"))

def autosize(ws, widths):
    for col, w in widths.items():
        ws.column_dimensions[col].width = w

def add_table(ws, df, start_row=1, start_col=1, table_name=None, style="TableStyleMedium9"):
    """Write a dataframe as a formatted Excel table starting at start_row/start_col."""
    n_rows, n_cols = df.shape
    for j, col_name in enumerate(df.columns):
        ws.cell(row=start_row, column=start_col + j, value=col_name)
    for i in range(n_rows):
        for j in range(n_cols):
            val = df.iat[i, j]
            if pd.isna(val):
                val = None
            elif isinstance(val, (np.integer,)):
                val = int(val)
            elif isinstance(val, (np.floating,)):
                val = float(val)
            ws.cell(row=start_row + 1 + i, column=start_col + j, value=val)
    style_header(ws, start_row, n_cols)
    end_row = start_row + n_rows
    end_col_letter = get_column_letter(start_col + n_cols - 1)
    start_col_letter = get_column_letter(start_col)
    ref = f"{start_col_letter}{start_row}:{end_col_letter}{end_row}"
    if table_name:
        tab = Table(displayName=table_name, ref=ref)
        tab.tableStyleInfo = TableStyleInfo(name=style, showRowStripes=True)
        ws.add_table(tab)
    return end_row, end_col_letter

# =====================================================================
# 0. README / INSTRUCTIONS SHEET
# =====================================================================
ws = wb.active
ws.title = "README"
ws.sheet_view.showGridLines = False
ws["B2"] = "Kenyan Fintech Analytics — Excel Workbook"
ws["B2"].font = Font(name=FONT, size=18, bold=True, color=NAVY)
ws["B4"] = "Part of the full Data Analyst Portfolio Project (SQL + Python + Excel + Tableau + Power BI)"
ws["B4"].font = Font(name=FONT, size=11, italic=True)

instructions = [
    ("", ""),
    ("How this workbook is organized", ""),
    ("Data_Customers / Data_Transactions / Data_Loans / Data_Fraud", "Raw data tables (loaded as Excel Tables so ranges auto-expand)"),
    ("KPI_Dashboard", "Executive summary KPIs using SUMIFS / COUNTIFS / AVERAGEIFS formulas referencing the Data_ sheets"),
    ("Monthly_Trend", "Month-by-month TPV, fee revenue and transaction volume (SUMIFS) + trend chart"),
    ("Channel_Analysis", "Success/failure/reversal rate by channel (COUNTIFS) + chart"),
    ("Customer_RFM", "Recency/Frequency/Monetary segmentation with formula-driven segment labels (IFS)"),
    ("Loan_Risk", "Portfolio-at-Risk (PAR) by days-past-due bucket + default rate by product, with chart"),
    ("", ""),
    ("How to use / extend it", ""),
    ("1.", "All 'Data_' sheets are Excel Tables — paste more raw rows in and every formula referencing the table auto-expands."),
    ("2.", "Every KPI/summary cell is a live formula (never a hard-typed number) — change the underlying data and the whole workbook recalculates."),
    ("3.", "Use Insert > PivotTable on any Data_ sheet to build your own cuts on top of what's provided."),
    ("4.", "Currency is Kenyan Shillings (KES)."),
    ("", ""),
    ("Recommended skills to demonstrate when you present this file", ""),
    ("-", "SUMIFS / COUNTIFS / AVERAGEIFS for conditional aggregation"),
    ("-", "INDEX/MATCH for lookups (see Customer_RFM sheet)"),
    ("-", "IFS for multi-branch classification logic (RFM segment, DPD risk bucket)"),
    ("-", "Excel Tables + native charts for a self-updating dashboard"),
    ("-", "Conditional formatting (data bars / color scales) for visual KPI scanning"),
]
r = 6
for a, b in instructions:
    ws.cell(row=r, column=2, value=a).font = Font(name=FONT, bold=(b == "" and a != ""), size=11,
                                                    color=NAVY if (b == "" and a != "") else "000000")
    ws.cell(row=r, column=3, value=b).font = Font(name=FONT, size=10)
    r += 1
autosize(ws, {"A": 3, "B": 32, "C": 90})

# =====================================================================
# 1. DATA SHEETS
# =====================================================================
customers = pd.read_csv("/home/claude/project/data/star_schema/dim_customer.csv")
tx = pd.read_csv("/home/claude/project/data/star_schema/fact_transactions.csv")
loans = pd.read_csv("/home/claude/project/data/star_schema/fact_loans.csv")
fraud = pd.read_csv("/home/claude/project/data/star_schema/fact_fraud_events.csv")

tx["transaction_date"] = pd.to_datetime(tx["transaction_date"])
tx["month"] = tx["transaction_date"].dt.strftime("%Y-%m")
tx_small = tx[["transaction_id","account_id","customer_id","transaction_date","month","transaction_type",
               "channel","amount_kes","fee_kes","status","recipient_type","is_flagged_fraud"]].copy()
tx_small["transaction_date"] = tx_small["transaction_date"].dt.strftime("%Y-%m-%d %H:%M")

cust_small = customers[["customer_id","first_name","last_name","gender","age","age_band","county_name",
                         "customer_type","occupation","income_band","kyc_status","customer_status",
                         "registration_date","tenure_days"]].copy()

loans_small = loans[["loan_id","customer_id","loan_product","application_date","approved_amount",
                      "interest_rate","term_days","loan_status","outstanding_balance","days_past_due"]].copy()

fraud_small = fraud[["fraud_event_id","transaction_id","detected_at","fraud_type","risk_score",
                      "investigation_status","confirmed_fraud"]].copy()

ws = wb.create_sheet("Data_Customers")
add_table(ws, cust_small, table_name="tbl_customers")
autosize(ws, {get_column_letter(i+1): 14 for i in range(len(cust_small.columns))})

ws = wb.create_sheet("Data_Transactions")
add_table(ws, tx_small, table_name="tbl_transactions")
autosize(ws, {get_column_letter(i+1): 15 for i in range(len(tx_small.columns))})

ws = wb.create_sheet("Data_Loans")
add_table(ws, loans_small, table_name="tbl_loans")
autosize(ws, {get_column_letter(i+1): 15 for i in range(len(loans_small.columns))})

ws = wb.create_sheet("Data_Fraud")
add_table(ws, fraud_small, table_name="tbl_fraud")
autosize(ws, {get_column_letter(i+1): 15 for i in range(len(fraud_small.columns))})

n_tx = len(tx_small)
n_loans = len(loans_small)
n_fraud = len(fraud_small)
n_cust = len(cust_small)

print("Data sheets written:", n_cust, n_tx, n_loans, n_fraud)

# Table column letters for formula references (Data_Transactions)
# columns: transaction_id A, account_id B, customer_id C, transaction_date D, month E,
#          transaction_type F, channel G, amount_kes H, fee_kes I, status J, recipient_type K, is_flagged_fraud L
TX = "Data_Transactions"
TX_RANGE = lambda col: f"{TX}!${col}$2:${col}${n_tx+1}"
AMOUNT_R = TX_RANGE("H"); FEE_R = TX_RANGE("I"); STATUS_R = TX_RANGE("J")
TYPE_R = TX_RANGE("F"); CHANNEL_R = TX_RANGE("G"); MONTH_R = TX_RANGE("E"); FRAUD_R = TX_RANGE("L")
TXID_R = TX_RANGE("A")

# Loans columns: loan_id A, customer_id B, loan_product C, application_date D, approved_amount E,
#                interest_rate F, term_days G, loan_status H, outstanding_balance I, days_past_due J
LN = "Data_Loans"
LN_RANGE = lambda col: f"{LN}!${col}$2:${col}${n_loans+1}"
LN_PRODUCT_R = LN_RANGE("C"); LN_STATUS_R = LN_RANGE("H"); LN_APPROVED_R = LN_RANGE("E")
LN_OUTSTANDING_R = LN_RANGE("I"); LN_DPD_R = LN_RANGE("J"); LN_RATE_R = LN_RANGE("F")

# =====================================================================
# 2. KPI DASHBOARD
# =====================================================================
ws = wb.create_sheet("KPI_Dashboard")
ws.sheet_view.showGridLines = False
ws["B2"] = "Executive KPI Dashboard"
ws["B2"].font = Font(name=FONT, size=16, bold=True, color=NAVY)
ws["B3"] = "All figures are live formulas over Data_Transactions / Data_Loans / Data_Fraud"
ws["B3"].font = Font(name=FONT, italic=True, size=10)

kpi_labels = [
    ("Total Transactions", f'=COUNTA({TXID_R})'),
    ("Completed Transactions", f'=COUNTIF({STATUS_R},"Completed")'),
    ("Success Rate (%)", f'=ROUND(C6/C5*100,2)'),
    ("Total Processing Value (TPV, KES)", f'=SUMIF({STATUS_R},"Completed",{AMOUNT_R})'),
    ("Total Fee Revenue (KES)", f'=SUMIF({STATUS_R},"Completed",{FEE_R})'),
    ("Average Transaction Value (KES)", f'=ROUND(C8/C6,2)'),
    ("Failed Transactions", f'=COUNTIF({STATUS_R},"Failed")'),
    ("Failure Rate (%)", f'=ROUND(C11/C5*100,2)'),
    ("Reversed Transactions", f'=COUNTIF({STATUS_R},"Reversed")'),
    ("Reversal Rate (%)", f'=ROUND(C13/C5*100,2)'),
    ("Total Active Customers (Data_Customers)", f'=COUNTIF(Data_Customers!$L$2:$L${n_cust+1},"Active")'),
    ("Total Loans Issued", f'=COUNTA({LN_RANGE("A")})'),
    ("Total Loan Disbursed (KES)", f'=SUMIF({LN_STATUS_R},"<>Rejected",{LN_APPROVED_R})'),
    ("Loans Defaulted", f'=COUNTIF({LN_STATUS_R},"Defaulted")'),
    ("Default Rate (%)", f'=ROUND(C18/C16*100,2)'),
    ("Total Outstanding Loan Balance (KES)", f'=SUMIF({LN_STATUS_R},"Active",{LN_OUTSTANDING_R})'),
    ("Fraud Alerts Raised", f'=COUNTA(Data_Fraud!$A$2:$A${n_fraud+1})'),
    ("Confirmed Fraud Cases", f'=COUNTIF(Data_Fraud!$F$2:$F${n_fraud+1},"Confirmed")'),
]
r = 5
for label, formula in kpi_labels:
    ws.cell(row=r, column=2, value=label).font = Font(name=FONT, size=11)
    cell = ws.cell(row=r, column=3, value=formula)
    cell.font = Font(name=FONT, size=12, bold=True, color=BLUE)
    ws.cell(row=r, column=2).fill = PatternFill("solid", fgColor=LIGHT if r % 2 == 0 else WHITE)
    ws.cell(row=r, column=3).fill = PatternFill("solid", fgColor=LIGHT if r % 2 == 0 else WHITE)
    r += 1
autosize(ws, {"A": 3, "B": 42, "C": 22})
for row in range(5, r):
    ws.cell(row=row, column=3).number_format = "#,##0.00"

# =====================================================================
# 3. MONTHLY TREND
# =====================================================================
ws = wb.create_sheet("Monthly_Trend")
months = sorted(tx_small["month"].unique())
ws["A1"] = "Month"; ws["B1"] = "Transactions"; ws["C1"] = "TPV (KES)"; ws["D1"] = "Fee Revenue (KES)"
style_header(ws, 1, 4)
for i, m in enumerate(months):
    row = i + 2
    ws.cell(row=row, column=1, value=m)
    ws.cell(row=row, column=2, value=f'=COUNTIFS({MONTH_R},A{row},{STATUS_R},"Completed")')
    ws.cell(row=row, column=3, value=f'=SUMIFS({AMOUNT_R},{MONTH_R},A{row},{STATUS_R},"Completed")')
    ws.cell(row=row, column=4, value=f'=SUMIFS({FEE_R},{MONTH_R},A{row},{STATUS_R},"Completed")')
    ws.cell(row=row, column=3).number_format = "#,##0"
    ws.cell(row=row, column=4).number_format = "#,##0"
last_row = len(months) + 1
autosize(ws, {"A": 12, "B": 14, "C": 16, "D": 16})

chart1 = LineChart()
chart1.title = "Monthly TPV Trend (KES)"
chart1.y_axis.title = "TPV (KES)"
chart1.x_axis.title = "Month"
data = Reference(ws, min_col=3, min_row=1, max_row=last_row)
cats = Reference(ws, min_col=1, min_row=2, max_row=last_row)
chart1.add_data(data, titles_from_data=True)
chart1.set_categories(cats)
chart1.height = 9; chart1.width = 22
ws.add_chart(chart1, "F2")

chart2 = BarChart()
chart2.type = "col"
chart2.title = "Monthly Fee Revenue (KES)"
data2 = Reference(ws, min_col=4, min_row=1, max_row=last_row)
chart2.add_data(data2, titles_from_data=True)
chart2.set_categories(cats)
chart2.height = 9; chart2.width = 22
ws.add_chart(chart2, "F20")

# =====================================================================
# 4. CHANNEL ANALYSIS
# =====================================================================
ws = wb.create_sheet("Channel_Analysis")
channels = sorted(tx_small["channel"].unique())
headers = ["Channel","Total Transactions","Completed","Failed","Reversed","Success Rate (%)","Total Value (KES)"]
for j, h in enumerate(headers):
    ws.cell(row=1, column=j+1, value=h)
style_header(ws, 1, len(headers))
for i, ch in enumerate(channels):
    row = i + 2
    ws.cell(row=row, column=1, value=ch)
    ws.cell(row=row, column=2, value=f'=COUNTIF({CHANNEL_R},A{row})')
    ws.cell(row=row, column=3, value=f'=COUNTIFS({CHANNEL_R},A{row},{STATUS_R},"Completed")')
    ws.cell(row=row, column=4, value=f'=COUNTIFS({CHANNEL_R},A{row},{STATUS_R},"Failed")')
    ws.cell(row=row, column=5, value=f'=COUNTIFS({CHANNEL_R},A{row},{STATUS_R},"Reversed")')
    ws.cell(row=row, column=6, value=f'=ROUND(C{row}/B{row}*100,2)')
    ws.cell(row=row, column=7, value=f'=SUMIFS({AMOUNT_R},{CHANNEL_R},A{row},{STATUS_R},"Completed")')
    ws.cell(row=row, column=7).number_format = "#,##0"
last_row_ch = len(channels) + 1
autosize(ws, {get_column_letter(i+1): 18 for i in range(len(headers))})

# conditional formatting: data bar on success rate
rule = DataBarRule(start_type="num", start_value=0, end_type="num", end_value=100, color="2E86AB")
ws.conditional_formatting.add(f"F2:F{last_row_ch}", rule)

chart3 = BarChart()
chart3.type = "col"
chart3.title = "Success Rate by Channel (%)"
data3 = Reference(ws, min_col=6, min_row=1, max_row=last_row_ch)
cats3 = Reference(ws, min_col=1, min_row=2, max_row=last_row_ch)
chart3.add_data(data3, titles_from_data=True)
chart3.set_categories(cats3)
chart3.height = 9; chart3.width = 16
ws.add_chart(chart3, "I2")

# =====================================================================
# 5. CUSTOMER RFM  (values computed in pandas — Recency/Frequency/
#    Monetary are inherently multi-step aggregations; the SEGMENT label
#    itself is a live IFS() formula so the classification logic is
#    visible and editable in Excel, not hardcoded)
# =====================================================================
rfm = pd.read_csv("/home/claude/project/data/star_schema/customer_rfm_segments.csv")
rfm = rfm.merge(cust_small[["customer_id","first_name","last_name","income_band"]], on="customer_id", how="left")
rfm_out = rfm[["customer_id","first_name","last_name","income_band","recency_days","frequency","monetary","R","F","M"]].copy()
rfm_out = rfm_out.sort_values("monetary", ascending=False).reset_index(drop=True)

ws = wb.create_sheet("Customer_RFM")
end_row, _ = add_table(ws, rfm_out, table_name="tbl_rfm")
# Add a live formula column for RFM segment (IFS) and RFM score (SUM)
ws.cell(row=1, column=11, value="RFM_Score")
ws.cell(row=1, column=12, value="Segment")
style_header(ws, 1, 12)
for i in range(len(rfm_out)):
    row = i + 2
    ws.cell(row=row, column=11, value=f"=H{row}+I{row}+J{row}")
    ws.cell(row=row, column=12, value=(
        f'=_xlfn.IFS(AND(H{row}>=4,I{row}>=4,J{row}>=4),"Champions",'
        f'AND(H{row}>=3,I{row}>=3),"Loyal Customers",'
        f'AND(H{row}>=4,I{row}<=2),"New / Promising",'
        f'AND(H{row}<=2,I{row}>=3),"At Risk",'
        f'AND(H{row}<=2,I{row}<=2),"Dormant / Churned",'
        f'TRUE,"Needs Attention")'
    ))
autosize(ws, {get_column_letter(i+1): 14 for i in range(12)})

# Segment summary + pie chart
ws2 = wb.create_sheet("RFM_Segment_Summary")
seg_list = ["Champions","Loyal Customers","New / Promising","At Risk","Dormant / Churned","Needs Attention"]
ws2["A1"] = "Segment"; ws2["B1"] = "Customer Count"
style_header(ws2, 1, 2)
for i, seg in enumerate(seg_list):
    row = i + 2
    ws2.cell(row=row, column=1, value=seg)
    ws2.cell(row=row, column=2, value=f'=COUNTIF(Customer_RFM!$L$2:$L${end_row},A{row})')
autosize(ws2, {"A": 20, "B": 16})

pie = PieChart()
pie.title = "Customer RFM Segments"
data_p = Reference(ws2, min_col=2, min_row=1, max_row=len(seg_list)+1)
cats_p = Reference(ws2, min_col=1, min_row=2, max_row=len(seg_list)+1)
pie.add_data(data_p, titles_from_data=True)
pie.set_categories(cats_p)
pie.height = 10; pie.width = 16
ws2.add_chart(pie, "D2")

# =====================================================================
# 6. LOAN RISK  (Portfolio at Risk by DPD bucket + default rate by product)
# =====================================================================
ws = wb.create_sheet("Loan_Risk")
ws["A1"] = "DPD Bucket"; ws["B1"] = "Loans"; ws["C1"] = "Outstanding Balance (KES)"
style_header(ws, 1, 3)
buckets = [
    ("Current (0 DPD)", 0, 0),
    ("1-30 DPD", 1, 30),
    ("31-90 DPD", 31, 90),
    ("90+ DPD (NPL)", 91, 99999),
]
for i, (label, lo, hi) in enumerate(buckets):
    row = i + 2
    ws.cell(row=row, column=1, value=label)
    ws.cell(row=row, column=2, value=(
        f'=COUNTIFS({LN_STATUS_R},"Active",{LN_DPD_R},">="&{lo},{LN_DPD_R},"<="&{hi})'
    ))
    ws.cell(row=row, column=3, value=(
        f'=SUMIFS({LN_OUTSTANDING_R},{LN_STATUS_R},"Active",{LN_DPD_R},">="&{lo},{LN_DPD_R},"<="&{hi})'
    ))
    ws.cell(row=row, column=3).number_format = "#,##0"
autosize(ws, {"A": 18, "B": 12, "C": 24})

pie2 = PieChart()
pie2.title = "Portfolio at Risk (PAR) by DPD Bucket"
data_par = Reference(ws, min_col=3, min_row=1, max_row=5)
cats_par = Reference(ws, min_col=1, min_row=2, max_row=5)
pie2.add_data(data_par, titles_from_data=True)
pie2.set_categories(cats_par)
pie2.height = 9; pie2.width = 15
ws.add_chart(pie2, "E2")

# Default rate by loan product
products_l = sorted(loans_small["loan_product"].unique())
ws["A9"] = "Loan Product"; ws["B9"] = "Loans"; ws["C9"] = "Defaulted"; ws["D9"] = "Default Rate (%)"; ws["E9"] = "Avg Interest Rate (%)"
style_header(ws, 9, 5)
for i, p in enumerate(products_l):
    row = 10 + i
    ws.cell(row=row, column=1, value=p)
    ws.cell(row=row, column=2, value=f'=COUNTIF({LN_PRODUCT_R},A{row})')
    ws.cell(row=row, column=3, value=f'=COUNTIFS({LN_PRODUCT_R},A{row},{LN_STATUS_R},"Defaulted")')
    ws.cell(row=row, column=4, value=f'=ROUND(C{row}/B{row}*100,2)')
    ws.cell(row=row, column=5, value=f'=ROUND(AVERAGEIF({LN_PRODUCT_R},A{row},{LN_RATE_R}),2)')
autosize(ws, {"D": 16, "E": 18})

chart4 = BarChart()
chart4.type = "col"
chart4.title = "Default Rate by Loan Product (%)"
data4 = Reference(ws, min_col=4, min_row=9, max_row=9+len(products_l))
cats4 = Reference(ws, min_col=1, min_row=10, max_row=9+len(products_l))
chart4.add_data(data4, titles_from_data=True)
chart4.set_categories(cats4)
chart4.height = 9; chart4.width = 15
ws.add_chart(chart4, "E11")

# Reorder sheets into a logical, presentation-ready order
order = ["README", "KPI_Dashboard", "Monthly_Trend", "Channel_Analysis", "Customer_RFM",
         "RFM_Segment_Summary", "Loan_Risk", "Data_Customers", "Data_Transactions",
         "Data_Loans", "Data_Fraud"]
wb._sheets = [wb[name] for name in order]
wb.active = 0

wb.save("/home/claude/project/excel/Fintech_Analyst_Workbook.xlsx")
print("Full workbook saved with", len(wb.sheetnames), "sheets:", wb.sheetnames)
