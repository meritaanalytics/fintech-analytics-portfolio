/* =====================================================================
   FINTECH ANALYTICS PROJECT - SQL MODULE 1: SCHEMA & SETUP
   Database  : fintech.db (SQLite) — Kenyan mobile-money / digital lending
   Author    : <Your Name>
   =====================================================================
   HOW TO USE
   1. Open with any SQLite client (DB Browser for SQLite, VS Code
      SQLite extension, or `sqlite3 fintech.db` on the command line).
   2. Run this file first if you want to recreate the star-schema views
      used by 02_business_questions.sql, Tableau and Power BI.
   3. The raw OLTP tables (customers, accounts, transactions, loans, ...)
      already exist in fintech.db - these views sit on top of them and
      do not modify the raw data.
   ===================================================================== */

-- ---------------------------------------------------------------------
-- 1. Quick data audit — row counts across every table
-- ---------------------------------------------------------------------
SELECT 'customers' AS table_name, COUNT(*) AS row_count FROM customers
UNION ALL SELECT 'accounts', COUNT(*) FROM accounts
UNION ALL SELECT 'merchants', COUNT(*) FROM merchants
UNION ALL SELECT 'agents', COUNT(*) FROM agents
UNION ALL SELECT 'transactions', COUNT(*) FROM transactions
UNION ALL SELECT 'loans', COUNT(*) FROM loans
UNION ALL SELECT 'loan_repayments', COUNT(*) FROM loan_repayments
UNION ALL SELECT 'fees', COUNT(*) FROM fees
UNION ALL SELECT 'fraud_events', COUNT(*) FROM fraud_events
UNION ALL SELECT 'beneficiaries', COUNT(*) FROM beneficiaries
UNION ALL SELECT 'products', COUNT(*) FROM products;

-- ---------------------------------------------------------------------
-- 2. Data-quality checks (a real analyst always does this before
--    trusting a KPI). Each query should return 0 rows if data is clean.
-- ---------------------------------------------------------------------

-- 2a. Orphan transactions (account_id not in accounts)
SELECT t.transaction_id, t.account_id
FROM transactions t
LEFT JOIN accounts a ON t.account_id = a.account_id
WHERE a.account_id IS NULL;

-- 2b. Duplicate transaction_ids
SELECT transaction_id, COUNT(*) c
FROM transactions
GROUP BY transaction_id
HAVING c > 1;

-- 2c. Negative or NULL transaction amounts
SELECT * FROM transactions WHERE amount_kes IS NULL OR amount_kes < 0;

-- 2d. Loans with approved_amount > requested_amount (should not happen)
SELECT * FROM loans WHERE approved_amount > requested_amount;

-- 2e. Customers with no accounts at all
SELECT c.customer_id
FROM customers c
LEFT JOIN accounts a ON c.customer_id = a.customer_id
WHERE a.account_id IS NULL;

-- ---------------------------------------------------------------------
-- 3. VIEW: v_dim_county — enrich county_id with real Kenyan county
--    names (dataset ships IDs only; documented assumption, see
--    docs/data_dictionary.md)
-- ---------------------------------------------------------------------
DROP VIEW IF EXISTS v_dim_county;
CREATE VIEW v_dim_county AS
SELECT 1  AS county_id, 'Nairobi'      AS county_name UNION ALL
SELECT 2,  'Mombasa'      UNION ALL
SELECT 3,  'Kisumu'       UNION ALL
SELECT 4,  'Nakuru'       UNION ALL
SELECT 5,  'Uasin Gishu'  UNION ALL
SELECT 6,  'Kiambu'       UNION ALL
SELECT 7,  'Machakos'     UNION ALL
SELECT 8,  'Kajiado'      UNION ALL
SELECT 9,  'Nyeri'        UNION ALL
SELECT 10, 'Meru'         UNION ALL
SELECT 11, 'Kakamega'     UNION ALL
SELECT 12, 'Bungoma'      UNION ALL
SELECT 13, 'Kilifi'       UNION ALL
SELECT 14, 'Garissa'      UNION ALL
SELECT 15, 'Kisii';

-- ---------------------------------------------------------------------
-- 4. VIEW: v_customer_360 — one row per customer with demographics,
--    balances, transaction behaviour and loan behaviour combined.
--    (fintech.db already ships a pre-aggregated customer_360 table;
--    this view shows how to build the same result from first
--    principles — useful to demonstrate SQL joins/aggregation skill)
-- ---------------------------------------------------------------------
DROP VIEW IF EXISTS v_customer_360;
CREATE VIEW v_customer_360 AS
SELECT
    c.customer_id,
    c.first_name || ' ' || c.last_name           AS customer_name,
    c.gender,
    c.customer_type,
    c.occupation,
    c.income_band,
    c.kyc_status,
    c.customer_status,
    v.county_name,
    c.registration_date,
    CAST(julianday('2025-12-31') - julianday(c.registration_date) AS INT) AS tenure_days,
    COUNT(DISTINCT a.account_id)                 AS account_count,
    COALESCE(SUM(DISTINCT a.current_balance), 0) AS total_balance_kes,
    COUNT(DISTINCT t.transaction_id)             AS transaction_count,
    COALESCE(SUM(t.amount_kes), 0)               AS transaction_value_kes,
    COALESCE(SUM(t.fee_kes), 0)                  AS total_fees_kes,
    MAX(t.transaction_date)                      AS last_transaction_date,
    COUNT(DISTINCT l.loan_id)                    AS loan_count,
    COALESCE(SUM(DISTINCT l.approved_amount), 0) AS approved_loan_kes,
    COALESCE(SUM(DISTINCT l.outstanding_balance),0) AS outstanding_loan_kes,
    COALESCE(MAX(l.days_past_due), 0)            AS max_dpd
FROM customers c
LEFT JOIN v_dim_county v      ON c.county_id = v.county_id
LEFT JOIN accounts a          ON c.customer_id = a.customer_id
LEFT JOIN transactions t      ON c.customer_id = t.customer_id AND t.status = 'Completed'
LEFT JOIN loans l             ON c.customer_id = l.customer_id
GROUP BY c.customer_id;

-- ---------------------------------------------------------------------
-- 5. VIEW: v_fact_transactions — transaction fact enriched with date
--    parts and fraud flag, ready for BI tools / pivoting.
-- ---------------------------------------------------------------------
DROP VIEW IF EXISTS v_fact_transactions;
CREATE VIEW v_fact_transactions AS
SELECT
    t.transaction_id,
    t.account_id,
    t.customer_id,
    t.transaction_date,
    strftime('%Y', t.transaction_date)            AS txn_year,
    strftime('%m', t.transaction_date)            AS txn_month,
    strftime('%Y-%m', t.transaction_date)         AS txn_year_month,
    CAST(strftime('%H', t.transaction_date) AS INT) AS txn_hour,
    t.transaction_type,
    t.channel,
    t.amount_kes,
    t.fee_kes,
    (t.amount_kes - COALESCE(t.fee_kes,0))        AS net_amount_kes,
    t.status,
    CASE WHEN t.status = 'Completed' THEN 1 ELSE 0 END AS is_successful,
    CASE WHEN t.status = 'Failed'    THEN 1 ELSE 0 END AS is_failed,
    CASE WHEN t.status = 'Reversed'  THEN 1 ELSE 0 END AS is_reversed,
    t.recipient_type,
    t.merchant_id,
    t.agent_id,
    f.fraud_type,
    f.risk_score,
    CASE WHEN f.transaction_id IS NOT NULL THEN 1 ELSE 0 END AS is_flagged_fraud
FROM transactions t
LEFT JOIN (
    SELECT transaction_id, fraud_type, risk_score,
           ROW_NUMBER() OVER (PARTITION BY transaction_id ORDER BY risk_score DESC) rn
    FROM fraud_events
) f ON t.transaction_id = f.transaction_id AND f.rn = 1;

-- ---------------------------------------------------------------------
-- 6. VIEW: v_loan_performance — loan-level performance metrics
-- ---------------------------------------------------------------------
DROP VIEW IF EXISTS v_loan_performance;
CREATE VIEW v_loan_performance AS
SELECT
    l.loan_id,
    l.customer_id,
    l.loan_product,
    l.application_date,
    l.approval_date,
    CAST(julianday(l.approval_date) - julianday(l.application_date) AS INT) AS days_to_approve,
    l.requested_amount,
    l.approved_amount,
    ROUND(l.approved_amount * 1.0 / NULLIF(l.requested_amount,0), 3) AS approval_rate,
    l.interest_rate,
    l.term_days,
    l.loan_status,
    l.outstanding_balance,
    l.days_past_due,
    CASE WHEN l.days_past_due > 90 THEN 'NPL (90+ DPD)'
         WHEN l.days_past_due > 30 THEN 'Watch (31-90 DPD)'
         WHEN l.days_past_due > 0  THEN 'Early Delinquency (1-30 DPD)'
         ELSE 'Current' END AS risk_bucket
FROM loans l;

SELECT 'Schema setup complete. Views created: v_dim_county, v_customer_360, v_fact_transactions, v_loan_performance' AS status;
