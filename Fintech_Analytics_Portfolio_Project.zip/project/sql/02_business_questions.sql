/* =====================================================================
   FINTECH ANALYTICS PROJECT - SQL MODULE 2: BUSINESS QUESTIONS
   Run 01_schema_setup.sql first (creates the views used below).
   Each block = one real stakeholder question a fintech analyst is
   asked, with the SQL an interviewer or manager would want to see.
   ===================================================================== */

-- =====================================================================
-- SECTION A: EXECUTIVE KPIs
-- =====================================================================

-- A1. Top-line KPI summary (TPV, revenue, active customers, success rate)
SELECT
    COUNT(DISTINCT customer_id)                                   AS active_customers,
    COUNT(*)                                                      AS total_transactions,
    ROUND(SUM(amount_kes), 2)                                     AS total_processing_value_kes,
    ROUND(SUM(fee_kes), 2)                                        AS total_fee_revenue_kes,
    ROUND(100.0 * SUM(is_successful) / COUNT(*), 2)               AS success_rate_pct,
    ROUND(100.0 * SUM(is_failed) / COUNT(*), 2)                   AS failure_rate_pct,
    ROUND(100.0 * SUM(is_reversed) / COUNT(*), 2)                 AS reversal_rate_pct,
    ROUND(AVG(amount_kes), 2)                                     AS avg_transaction_value_kes
FROM v_fact_transactions;

-- A2. Monthly Total Processing Value (TPV) & revenue trend
SELECT
    txn_year_month,
    COUNT(*)                          AS transactions,
    ROUND(SUM(amount_kes), 2)         AS tpv_kes,
    ROUND(SUM(fee_kes), 2)            AS fee_revenue_kes,
    ROUND(SUM(amount_kes) - LAG(SUM(amount_kes)) OVER (ORDER BY txn_year_month), 2) AS mom_tpv_change,
    ROUND(100.0 * (SUM(amount_kes) - LAG(SUM(amount_kes)) OVER (ORDER BY txn_year_month))
          / NULLIF(LAG(SUM(amount_kes)) OVER (ORDER BY txn_year_month),0), 2)       AS mom_tpv_growth_pct
FROM v_fact_transactions
WHERE status = 'Completed'
GROUP BY txn_year_month
ORDER BY txn_year_month;

-- A3. Revenue mix by transaction type and channel
SELECT
    transaction_type,
    channel,
    COUNT(*)                       AS transactions,
    ROUND(SUM(amount_kes), 2)      AS tpv_kes,
    ROUND(SUM(fee_kes), 2)         AS fee_revenue_kes,
    ROUND(100.0 * SUM(fee_kes) / SUM(SUM(fee_kes)) OVER (), 2) AS pct_of_total_revenue
FROM v_fact_transactions
WHERE status = 'Completed'
GROUP BY transaction_type, channel
ORDER BY fee_revenue_kes DESC;

-- A4. Channel performance — success/failure by channel (ops health)
SELECT
    channel,
    COUNT(*)                                        AS transactions,
    ROUND(100.0 * SUM(is_successful) / COUNT(*), 2) AS success_rate_pct,
    ROUND(100.0 * SUM(is_failed) / COUNT(*), 2)      AS failure_rate_pct,
    ROUND(100.0 * SUM(is_reversed) / COUNT(*), 2)    AS reversal_rate_pct
FROM v_fact_transactions
GROUP BY channel
ORDER BY transactions DESC;

-- A5. Peak transaction hours (for infrastructure / staffing planning)
SELECT txn_hour, COUNT(*) AS transactions, ROUND(SUM(amount_kes),2) AS tpv_kes
FROM v_fact_transactions
GROUP BY txn_hour
ORDER BY txn_hour;

-- A6. Weekday vs weekend behaviour
SELECT
    CASE WHEN strftime('%w', transaction_date) IN ('0','6') THEN 'Weekend' ELSE 'Weekday' END AS day_type,
    COUNT(*) AS transactions,
    ROUND(AVG(amount_kes), 2) AS avg_amount_kes
FROM v_fact_transactions
GROUP BY day_type;


-- =====================================================================
-- SECTION B: CUSTOMER ANALYTICS
-- =====================================================================

-- B1. Customer segmentation by income band — value & activity
SELECT
    income_band,
    COUNT(*)                              AS customers,
    ROUND(AVG(total_balance_kes), 2)      AS avg_balance_kes,
    ROUND(AVG(transaction_value_kes), 2)  AS avg_txn_value_kes,
    ROUND(AVG(transaction_count), 1)      AS avg_txn_count
FROM v_customer_360
GROUP BY income_band
ORDER BY avg_balance_kes DESC;

-- B2. RFM segmentation (Recency, Frequency, Monetary) — classic
--     fintech/marketing analytics technique using NTILE for quintiles
WITH rfm_base AS (
    SELECT
        customer_id,
        CAST(julianday('2025-12-31') - julianday(MAX(transaction_date)) AS INT) AS recency_days,
        COUNT(*)                    AS frequency,
        SUM(amount_kes)             AS monetary
    FROM v_fact_transactions
    WHERE status = 'Completed'
    GROUP BY customer_id
),
rfm_scored AS (
    SELECT *,
        NTILE(5) OVER (ORDER BY recency_days DESC) AS r_score,  -- lower recency_days = more recent = higher score
        NTILE(5) OVER (ORDER BY frequency ASC)     AS f_score,
        NTILE(5) OVER (ORDER BY monetary ASC)      AS m_score
    FROM rfm_base
)
SELECT
    customer_id, recency_days, frequency, monetary, r_score, f_score, m_score,
    (r_score + f_score + m_score) AS rfm_total,
    CASE
        WHEN r_score >= 4 AND f_score >= 4 AND m_score >= 4 THEN 'Champions'
        WHEN r_score >= 3 AND f_score >= 3                  THEN 'Loyal Customers'
        WHEN r_score >= 4 AND f_score <= 2                  THEN 'New / Promising'
        WHEN r_score <= 2 AND f_score >= 3                  THEN 'At Risk'
        WHEN r_score <= 2 AND f_score <= 2                  THEN 'Dormant / Churned'
        ELSE 'Needs Attention'
    END AS rfm_segment
FROM rfm_scored
ORDER BY rfm_total DESC;

-- B3. Cohort retention — % of customers still transacting N months
--     after their registration month (monthly cohort analysis)
WITH cohorts AS (
    SELECT customer_id, strftime('%Y-%m', registration_date) AS cohort_month
    FROM customers
),
activity AS (
    SELECT customer_id, strftime('%Y-%m', transaction_date) AS activity_month
    FROM transactions
    WHERE status = 'Completed'
    GROUP BY customer_id, activity_month
)
SELECT
    c.cohort_month,
    CAST(
      (strftime('%Y', a.activity_month || '-01') - strftime('%Y', c.cohort_month || '-01')) * 12 +
      (strftime('%m', a.activity_month || '-01') - strftime('%m', c.cohort_month || '-01'))
      AS INT) AS month_number,
    COUNT(DISTINCT a.customer_id) AS active_customers
FROM cohorts c
JOIN activity a ON c.customer_id = a.customer_id
GROUP BY c.cohort_month, month_number
ORDER BY c.cohort_month, month_number;

-- B4. Customer lifetime value proxy — total fee revenue generated per
--     customer, ranked (top revenue-generating customers)
SELECT customer_id, customer_name, income_band, transaction_count,
       transaction_value_kes, total_fees_kes,
       RANK() OVER (ORDER BY total_fees_kes DESC) AS revenue_rank
FROM v_customer_360
ORDER BY total_fees_kes DESC
LIMIT 20;

-- B5. Dormant / at-risk customers (no transaction in 60+ days but were
--     previously active) — churn-prevention target list
SELECT customer_id, customer_name, income_band, last_transaction_date,
       CAST(julianday('2025-12-31') - julianday(last_transaction_date) AS INT) AS days_since_last_txn
FROM v_customer_360
WHERE transaction_count > 0
  AND julianday('2025-12-31') - julianday(last_transaction_date) > 60
ORDER BY days_since_last_txn DESC;

-- B6. KYC funnel — verified vs pending, and whether it correlates with activity
SELECT kyc_status,
       COUNT(*) AS customers,
       ROUND(AVG(transaction_count), 1) AS avg_txn_count,
       ROUND(AVG(total_balance_kes), 2) AS avg_balance_kes
FROM v_customer_360
GROUP BY kyc_status;


-- =====================================================================
-- SECTION C: FRAUD & RISK ANALYTICS
-- =====================================================================

-- C1. Fraud rate overview
SELECT
    COUNT(*)                                                      AS total_flagged,
    SUM(CASE WHEN investigation_status = 'Confirmed' THEN 1 ELSE 0 END) AS confirmed_cases,
    ROUND(100.0 * SUM(CASE WHEN investigation_status='Confirmed' THEN 1 ELSE 0 END)/COUNT(*),2) AS confirmed_rate_pct,
    ROUND(AVG(risk_score), 3)                                     AS avg_risk_score
FROM fraud_events;

-- C2. Fraud by type and outcome
SELECT fraud_type, investigation_status, COUNT(*) AS cases, ROUND(AVG(risk_score),3) AS avg_risk_score
FROM fraud_events
GROUP BY fraud_type, investigation_status
ORDER BY fraud_type, cases DESC;

-- C3. Fraud exposure in KES — value of flagged transactions
SELECT
    f.fraud_type,
    COUNT(*)                     AS flagged_transactions,
    ROUND(SUM(t.amount_kes), 2)  AS exposure_kes,
    ROUND(AVG(f.risk_score), 3)  AS avg_risk_score
FROM fraud_events f
JOIN transactions t ON f.transaction_id = t.transaction_id
GROUP BY f.fraud_type
ORDER BY exposure_kes DESC;

-- C4. High-risk channel/type combinations (where fraud concentrates)
SELECT
    t.channel, t.transaction_type,
    COUNT(f.transaction_id)                                   AS fraud_flags,
    COUNT(t.transaction_id)                                   AS total_txns,
    ROUND(100.0 * COUNT(f.transaction_id) / COUNT(t.transaction_id), 3) AS fraud_rate_pct
FROM transactions t
LEFT JOIN fraud_events f ON t.transaction_id = f.transaction_id
GROUP BY t.channel, t.transaction_type
HAVING total_txns > 20
ORDER BY fraud_rate_pct DESC;

-- C5. Repeat-flagged customers (multiple fraud alerts = higher priority review)
SELECT t.customer_id, COUNT(*) AS fraud_flags, ROUND(AVG(f.risk_score),3) AS avg_risk_score
FROM fraud_events f
JOIN transactions t ON f.transaction_id = t.transaction_id
GROUP BY t.customer_id
HAVING fraud_flags > 1
ORDER BY fraud_flags DESC;


-- =====================================================================
-- SECTION D: LENDING / CREDIT RISK ANALYTICS
-- =====================================================================

-- D1. Loan portfolio overview
SELECT
    loan_product,
    COUNT(*)                                    AS loans_issued,
    ROUND(SUM(approved_amount), 2)              AS total_disbursed_kes,
    ROUND(AVG(approved_amount), 2)              AS avg_loan_size_kes,
    ROUND(AVG(interest_rate), 2)                AS avg_interest_rate_pct,
    ROUND(100.0 * SUM(CASE WHEN loan_status='Defaulted' THEN 1 ELSE 0 END)/COUNT(*), 2) AS default_rate_pct
FROM loans
GROUP BY loan_product
ORDER BY total_disbursed_kes DESC;

-- D2. Portfolio at Risk (PAR) — outstanding balance by DPD bucket,
--     the #1 metric microfinance/fintech risk teams report weekly
SELECT
    risk_bucket,
    COUNT(*)                          AS loans,
    ROUND(SUM(outstanding_balance),2) AS outstanding_kes,
    ROUND(100.0 * SUM(outstanding_balance) / SUM(SUM(outstanding_balance)) OVER (), 2) AS pct_of_portfolio
FROM v_loan_performance
WHERE loan_status = 'Active'
GROUP BY risk_bucket
ORDER BY CASE risk_bucket
    WHEN 'Current' THEN 1 WHEN 'Early Delinquency (1-30 DPD)' THEN 2
    WHEN 'Watch (31-90 DPD)' THEN 3 ELSE 4 END;

-- D3. Loan approval funnel & approval rate by product
SELECT
    loan_product,
    COUNT(*)                                                        AS applications,
    SUM(CASE WHEN loan_status != 'Rejected' THEN 1 ELSE 0 END)      AS approved,
    ROUND(100.0 * SUM(CASE WHEN loan_status != 'Rejected' THEN 1 ELSE 0 END) / COUNT(*), 2) AS approval_rate_pct,
    ROUND(AVG(days_to_approve), 1)                                  AS avg_days_to_approve
FROM v_loan_performance
GROUP BY loan_product;

-- D4. Repayment performance — on-time vs late vs missed
SELECT
    repayment_status,
    COUNT(*)                        AS repayments,
    ROUND(SUM(amount_due), 2)       AS total_due_kes,
    ROUND(SUM(amount_paid), 2)      AS total_paid_kes,
    ROUND(SUM(amount_due - amount_paid), 2) AS shortfall_kes
FROM loan_repayments
GROUP BY repayment_status;

-- D5. Default rate by customer income band (credit risk driver analysis)
SELECT
    c.income_band,
    COUNT(l.loan_id)                                                       AS loans,
    ROUND(100.0 * SUM(CASE WHEN l.loan_status='Defaulted' THEN 1 ELSE 0 END)/COUNT(l.loan_id), 2) AS default_rate_pct,
    ROUND(AVG(l.interest_rate), 2)                                         AS avg_interest_rate_pct
FROM loans l
JOIN customers c ON l.customer_id = c.customer_id
GROUP BY c.income_band
ORDER BY default_rate_pct DESC;

-- D6. Customers holding both a loan AND flagged fraud events
--     (cross-sell risk / compounded exposure view)
SELECT DISTINCT l.customer_id, l.loan_status, l.outstanding_balance
FROM loans l
JOIN transactions t ON l.customer_id = t.customer_id
JOIN fraud_events f ON t.transaction_id = f.transaction_id
WHERE l.loan_status = 'Active';


-- =====================================================================
-- SECTION E: MERCHANT & AGENT NETWORK ANALYTICS
-- =====================================================================

-- E1. Top merchants by transaction value (merchant acquiring insights)
SELECT
    m.merchant_name, m.merchant_category, v.county_name,
    COUNT(t.transaction_id)          AS transactions,
    ROUND(SUM(t.amount_kes), 2)      AS total_value_kes
FROM merchants m
JOIN transactions t ON m.merchant_id = t.merchant_id
LEFT JOIN v_dim_county v ON m.county_id = v.county_id
WHERE t.status = 'Completed'
GROUP BY m.merchant_id
ORDER BY total_value_kes DESC
LIMIT 15;

-- E2. Merchant category performance
SELECT merchant_category,
       COUNT(DISTINCT m.merchant_id)  AS merchants,
       COUNT(t.transaction_id)        AS transactions,
       ROUND(SUM(t.amount_kes), 2)    AS total_value_kes
FROM merchants m
LEFT JOIN transactions t ON m.merchant_id = t.merchant_id AND t.status='Completed'
GROUP BY merchant_category
ORDER BY total_value_kes DESC;

-- E3. Agent network activity (cash-in/cash-out agent performance)
SELECT
    ag.agent_name, v.county_name, ag.agent_status,
    COUNT(t.transaction_id)     AS transactions,
    ROUND(SUM(t.amount_kes), 2) AS total_value_kes
FROM agents ag
LEFT JOIN transactions t ON ag.agent_id = t.agent_id AND t.status = 'Completed'
LEFT JOIN v_dim_county v ON ag.county_id = v.county_id
GROUP BY ag.agent_id
ORDER BY total_value_kes DESC
LIMIT 15;

-- E4. Geographic performance — TPV and customer count by county
SELECT
    v.county_name,
    COUNT(DISTINCT c.customer_id)   AS customers,
    COUNT(t.transaction_id)         AS transactions,
    ROUND(SUM(t.amount_kes), 2)     AS tpv_kes
FROM customers c
LEFT JOIN v_dim_county v      ON c.county_id = v.county_id
LEFT JOIN transactions t      ON c.customer_id = t.customer_id AND t.status='Completed'
GROUP BY v.county_name
ORDER BY tpv_kes DESC;


-- =====================================================================
-- SECTION F: OPERATIONS / TRANSACTION LIFECYCLE
-- =====================================================================

-- F1. Average time a transaction spends in each status
--     (using transaction_status_history)
SELECT status,
       COUNT(*) AS occurrences,
       ROUND(AVG(julianday(changed_at) - julianday(
            (SELECT MIN(h2.changed_at) FROM transaction_status_history h2
             WHERE h2.transaction_id = h1.transaction_id)
       )) * 24 * 60, 1) AS avg_minutes_since_first_status
FROM transaction_status_history h1
GROUP BY status;

-- F2. Reasons behind failed/reversed transactions
SELECT reason, COUNT(*) AS occurrences
FROM transaction_status_history
WHERE status IN ('Failed', 'Reversed')
GROUP BY reason
ORDER BY occurrences DESC;

-- F3. Fee revenue reconciliation — does the fees table match
--     transactions.fee_kes? (data-quality / finance reconciliation check)
SELECT
    ROUND(SUM(t.fee_kes), 2)  AS fee_kes_on_transactions,
    ROUND(SUM(fs.total_fee_amount), 2) AS fee_kes_on_fee_table,
    ROUND(SUM(t.fee_kes) - SUM(fs.total_fee_amount), 2) AS variance_kes
FROM transactions t
JOIN transaction_fee_summary fs ON t.transaction_id = fs.transaction_id;

-- End of business-questions module.
